# V1.5 视觉与动作合理性门禁

适用于新素材和新剧情。执行器先从剧情生成项目合同，再由 Blender/Godot 输出实测报告；生成模型和动作库只提供输入，不拥有验收权。

## 责任边界

- 用户决定创意目标、可接受的风格回退和确认模式。若明确启用受控无人托管，执行器依据本文件门禁决定模型回退与最终代表帧放行。
- 生成服务提供原始资产；Blender 负责结构、比例、骨骼、接触和动作；Godot 负责场景关系、运动、镜头、时间线和 VFX。
- 执行器负责组合合理性、失败路由和停止。发现错误时回到拥有该问题的阶段，不把技术排错转交给用户。

## 项目语义报告

项目验证器应输出 JSON，并至少覆盖当前剧情真正存在的元素。示例：

```json
{
  "hero_assets": {"vehicle": {"source": "generated_3d", "model": "hunyuan-v3.1", "selection_rationale": "realistic textured vehicle from one clear reference", "formal": true}},
  "environment": {
    "formal": true, "q0_visible": false, "ground_material": "pbr",
    "depth_layers": 3, "unique_setpieces": 3, "repetition_score": 0.2,
    "empty_screen_ratio": 0.3, "camera_path_coverage": 0.95
  },
  "vehicles": [{"id": "hero", "role": "hero", "continuous_forward": true, "forward_dot": 0.999}],
  "riders": [{
    "id": "driver", "role": "driver", "posture": "seated",
    "seat_contact_m": 0.03, "hip_flexion_deg": 88, "knee_flexion_deg": 96,
    "left_hand_target_m": 0.03, "right_hand_target_m": 0.03,
    "left_foot_target_m": 0.06, "right_foot_target_m": 0.05
  }],
  "vfx": [{
    "id": "blast", "kind": "explosion", "representation": "soft_billboard_particles",
    "soft_alpha": true, "layers": ["flash", "fire", "smoke", "dust", "debris"],
    "smoke_rise_mps": 1.8, "opacity_decay": true, "wind_response": true,
    "max_strong_occlusion_frames": 6, "white_clip_ratio": 0.02
  }]
}
```

调用：

```powershell
python scripts/godot_project_gate.py `
  --godot C:\path\to\godot_console.exe `
  --project C:\path\to\project `
  --validator res://tests/validate_scene.gd `
  --success-marker GODOT_GATE_OK `
  --scene-semantics reports/scene-semantics.json `
  --output reports/godot-gate.json
```

可用 `--semantics-contract` 覆盖项目阈值；不得为了让失败稿通过而放宽阈值。默认主角正式资产源为 `generated_3d`、`licensed_asset` 或 `photogrammetry`，程序化回退必须在报告中带 `fallback_approved: true`。

## 生成模型路由

先查询当前获准使用的 3D 生成服务实际支持哪些模型，把允许列表写进项目合同，不根据旧记忆假定可用性。通用候选路线可包括：

- `hunyuan-v3.1`：有清晰图片参考、需要 PBR 纹理的中高面数候选。
- `tripo-v3.1`：高精度三角网格候选，适合多视图或几何细节优先的资产。
- `tripo-P1`：智能低模候选，适合远景、重复道具和明确的实时面数预算。
- `rodin-gen-2.5`：支持文本或图片驱动及不同导出/质量档位，适合需要明确几何预算和格式的候选。

这些是路由条件，不是质量结论。任何模型输出都要经过相同的多视图外观、比例、拓扑、拆件、PBR、碰撞、LOD 和引擎复验。报告使用 `source: generated_3d`、精确 `model` 和非空 `selection_rationale`；禁止把某一模型名称当成自动 PASS。

## 通用合理性

- 空间：落地、落座、抓握、脚舱、座舱和父子空间一致；不悬空、不穿模。
- 动作：关节角、重心、速度、惯性、后坐力与冲击方向可解释；动作名存在不等于动作成立。
- 因果：开火、命中、躲避、爆炸和反应按时间线连续；不能先反应后起因。
- 视觉：主次、剪影、竖屏安全区、遮挡和方向清晰；技术成功不代替视觉检查。
- 环境：正式地面使用可读的 PBR 材质，镜头路径具有前中后景和独特主景件；禁止用均匀平地、重复方块或大片空白冒充正式场景。

## 代表帧前停止条件

默认模式在代表帧后等待用户接受。受控无人托管模式不暂停，但必须用同一正式场景输出开场、动作、主爆炸、载具/敌方和收尾等关键帧；执行器逐帧记录 PASS/FAIL，任何 FAIL 必须返工后再渲染全片。

以下任一项存在就停止：主角仍是未批准的 Q0、环境仍暴露占位件或缺少景深覆盖、角色关系与剧情语义不符、运动轴反向、交互接触超差、VFX 使用不透明几何堆叠、强遮挡超出合同、烟火过曝或项目语义报告缺失。修复后必须重新运行 Godot 门禁并重新生成代表帧。
