# V1.4 执行器协议

## 合同根结构

```json
{
  "schema_version": "1.4",
  "project": {
    "name": "example",
    "quality": "Q2",
    "duration_seconds": 15,
    "fps": 30,
    "frame_count": 450,
    "resolution": [1080, 1920],
    "preview_only": true
  },
  "tools": {
    "blender": {"path": "auto", "version_args": ["--version"]},
    "godot": {"path": "auto", "version_args": ["--version"]}
  },
  "stages": []
}
```

项目时长限定 1–30 秒。`frame_count` 是记录字段，初始化时由时长乘帧率生成；项目测试仍应验证时间线完全一致。

## 阶段字段

```json
{
  "id": "rig_gate",
  "type": "command",
  "configured": true,
  "inputs": ["assets/character.blend", "config/rig-gate.json"],
  "outputs": ["reports/rig-gate.json"],
  "command": [
    "C:/Program Files/Blender Foundation/Blender 5.2/blender.exe",
    "--background",
    "--python",
    "C:/Users/your-name/.codex/skills/3d-pipeline/scripts/blender_rig_gate.py",
    "--",
    "--input",
    "assets/character.blend",
    "--config",
    "config/rig-gate.json",
    "--output",
    "reports/rig-gate.json"
  ],
  "report": {
    "path": "reports/rig-gate.json",
    "status_field": "status",
    "pass_values": ["PASS"]
  },
  "timeout_seconds": 1800
}
```

- `command` 必须是数组；执行器使用 `shell=false`，不解释管道、重定向或命令拼接。
- 相对路径相对合同目录。命令元素支持 `{config_dir}` 和 `{config}`。
- `inputs` 和 `outputs` 会记录 SHA-256。已通过阶段只在输入和输出哈希都未变化时跳过。
- 输出不存在时不能命中缓存。
- `always_run: true` 的实时健康阶段每次都执行；`blender_mcp_gate` 使用此字段，不能拿旧报告证明当前连接。
- `report` 可选；一旦声明，退出码 0 但报告状态不是 `PASS` 仍然失败。
- 不要在合同、命令或报告中放 API Key、Cookie、OTP 或其他凭据。

## 审批字段

```json
{
  "id": "external_generation",
  "type": "command",
  "requires_approvals": ["external_generation"],
  "command": ["..."],
  "inputs": ["..."],
  "outputs": ["..."]
}
```

审批记录在 `.3d-pipeline/run-state.json`，绑定完整合同哈希。只有用户明确同意当前模型、数量、输入、费用/额度、重试上限和验收点后才记录。失败重试使用新的审批门或修改合同后重新审批。

## 资产门禁配置

```json
{
  "quality": "Q2",
  "target_height_m": 1.78,
  "thresholds": {
    "min_vertices": 10000,
    "min_materials": 1,
    "max_triangles": 2000000
  },
  "hand_regions": [
    {
      "id": "L",
      "mesh_name": "CharacterBody",
      "min": [0.55, -0.25, 1.10],
      "max": [0.90, 0.10, 1.35],
      "min_vertices": 100,
      "min_component_vertices": 8,
      "max_total_components": 12,
      "max_significant_components": 8
    }
  ]
}
```

示例坐标只说明格式，不能复制到其他角色。左右手都要依据该资产的规范化 T/A-Pose 实测设置。

## 骨骼与握持配置

```json
{
  "mesh_name": "CharacterBody",
  "armature_name": "CharacterRig",
  "action_name": "GripTest",
  "rest_frame": 1,
  "pose_frame": 30,
  "required_bones": ["root", "upper_arm.L", "forearm.L", "hand.L"],
  "required_vertex_groups": ["hand.L", "thumb.01.L", "index.01.L"],
  "minimum_weight": 0.05,
  "minimum_vertices_per_group": 1,
  "minimum_pose_displacement_m": 0.001,
  "max_edge_stretch_ratio": 2.2,
  "max_edge_extension_m": 0.004,
  "grip": {
    "half_length_m": 0.085,
    "radius_m": 0.026,
    "contact_tolerance_m": 0.014,
    "max_palm_penetration_m": 0.008,
    "max_hand_target_distance_m": 0.12,
    "max_thumb_opposition_dot": -0.10,
    "sides": {
      "L": {
        "centre": [0.235, -0.300, 1.120],
        "axis": [0, 0, 1],
        "hand_groups": ["hand.L"],
        "digits": {
          "thumb": ["thumb.01.L", "thumb.02.L", "thumb.03.L"],
          "index": ["index.01.L", "index.02.L", "index.03.L"],
          "middle": ["middle.01.L", "middle.02.L", "middle.03.L"],
          "ring": ["ring.01.L", "ring.02.L", "ring.03.L"],
          "pinky": ["pinky.01.L", "pinky.02.L", "pinky.03.L"]
        }
      }
    }
  }
}
```

左右手需要分别配置。握把参数来自正式武器局部坐标；若角色和武器不在同一坐标空间，先把固定握点转换到角色网格世界空间再写入合同。

## Godot 门禁命令

```powershell
python scripts/godot_project_gate.py `
  --godot 'C:\path\to\Godot_console.exe' `
  --project 'C:\path\to\godot_project' `
  --validator 'res://tests/validate_production_scene.gd' `
  --success-marker 'GODOT_PRODUCTION_SCENE_OK' `
  --output 'C:\path\to\reports\godot-gate.json'
```

项目验证器负责项目语义；包装器只确认真实 Godot 进程退出 0 且出现成功标记。验证器至少应检查正式实例可见、Skeleton3D 实际姿态变化、代理禁用、时间线、数量、镜头、灯光和关键交互。

## Blender-MCP 实时门禁

新合同默认配置此阶段：

```powershell
python scripts/blender_mcp_gate.py `
  --start-if-needed `
  --blender auto `
  --expected-protocol 5 `
  --output reports/blender-mcp-gate.json
```

门禁先连接 `127.0.0.1:9876`；不可达时启动 Blender GUI，等待插件自动开启 Socket 服务，再执行 `get_addon_info` 和 `get_scene_info`。只有协议匹配且真实场景查询成功才返回 `PASS/MCP_LIVE`。

## Mixamo 自动交接

`pipeline.py configure-mixamo` 读取项目级 Mixamo 配置，核对角色和动作文件实际存在，然后自动写入 `mixamo_handoff` 的输入哈希、Blender 命令、输出文件和机器报告。运行阶段调用 `blender_mixamo_handoff.py`，输出：

- 带全部映射动作的 `.blend`；
- 可由 Godot 导入的 `.glb`；
- 包含输入 SHA-256、骨名/曲线映射数、休止骨轴误差、动作姿态变化和 Root Motion 模式的 JSON 报告。

自动交接拒绝缺骨、左右交换、骨轴超差、零映射曲线和静态动作。Mixamo 网页登录、上传和文件下载不在执行器权限内。

## 退出码

| 退出码 | 含义 |
|---:|---|
| 0 | 已执行范围内全部通过 |
| 2 | 合同、路径、命令或预检错误 |
| 3 | 缺少用户审批 |
| 4 | 命令退出 0，但机器报告未通过 |
| 5 | 阶段超时 |
| 6 | 阶段尚未配置 |
| 其他 | 原阶段命令的非零退出码 |
