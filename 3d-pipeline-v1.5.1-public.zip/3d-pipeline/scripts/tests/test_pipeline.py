import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "pipeline.py"


class PipelineCliTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)

    def tearDown(self):
        self.temp_dir.cleanup()

    def run_cli(self, *args):
        return subprocess.run(
            [sys.executable, str(SCRIPT), *map(str, args)],
            cwd=self.root,
            text=True,
            capture_output=True,
            encoding="utf-8",
        )

    def write_config(self, stages):
        path = self.root / "pipeline.json"
        path.write_text(
            json.dumps(
                {
                    "schema_version": "1.4",
                    "project": {
                        "name": "test-project",
                        "quality": "Q2",
                        "duration_seconds": 15,
                        "fps": 30,
                        "resolution": [1080, 1920],
                    },
                    "tools": {},
                    "stages": stages,
                }
            ),
            encoding="utf-8",
        )
        return path

    def test_init_creates_machine_readable_contract_and_state(self):
        workspace = self.root / "demo"
        result = self.run_cli(
            "init",
            "--workspace",
            workspace,
            "--name",
            "demo",
            "--quality",
            "Q2",
            "--duration",
            "15",
            "--fps",
            "30",
            "--resolution",
            "1080x1920",
        )

        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        config = json.loads((workspace / "3d-pipeline.json").read_text(encoding="utf-8"))
        state = json.loads((workspace / ".3d-pipeline" / "run-state.json").read_text(encoding="utf-8"))
        self.assertEqual(config["schema_version"], "1.4")
        self.assertEqual(config["project"]["quality"], "Q2")
        self.assertEqual(config["project"]["frame_count"], 450)
        self.assertEqual(state["pipeline_status"], "pending")
        self.assertEqual(
            [stage["id"] for stage in config["stages"]],
            [
                "preflight",
                "blender_mcp_gate",
                "asset_gate",
                "mixamo_handoff",
                "rig_gate",
                "export_gate",
                "godot_gate",
                "representative_frame",
                "final_render",
            ],
        )
        mcp_stage = next(stage for stage in config["stages"] if stage["id"] == "blender_mcp_gate")
        self.assertTrue(mcp_stage["configured"])
        self.assertTrue(mcp_stage["always_run"])
        self.assertEqual(mcp_stage["report"]["path"], "reports/blender-mcp-gate.json")
        mixamo_stage = next(stage for stage in config["stages"] if stage["id"] == "mixamo_handoff")
        self.assertFalse(mixamo_stage["configured"])

    def test_run_stops_at_first_failed_gate(self):
        marker = self.root / "later-stage-ran.txt"
        stages = [
            {
                "id": "asset_gate",
                "type": "command",
                "command": [sys.executable, "-c", "print('SOURCE_NOT_RIGGABLE'); raise SystemExit(17)"],
            },
            {
                "id": "rig_gate",
                "type": "command",
                "command": [sys.executable, "-c", f"from pathlib import Path; Path(r'{marker}').write_text('ran')"],
            },
        ]
        config = self.write_config(stages)

        result = self.run_cli("run", "--config", config)

        self.assertEqual(result.returncode, 17, result.stderr + result.stdout)
        self.assertFalse(marker.exists())
        state = json.loads((self.root / ".3d-pipeline" / "run-state.json").read_text(encoding="utf-8"))
        self.assertEqual(state["stages"]["asset_gate"]["status"], "failed")
        self.assertEqual(state["stages"]["rig_gate"]["status"], "pending")
        self.assertIn("SOURCE_NOT_RIGGABLE", state["stages"]["asset_gate"]["stdout"])

    def test_command_is_not_executed_before_required_approval(self):
        marker = self.root / "paid-command-ran.txt"
        config = self.write_config(
            [
                {
                    "id": "external_generation",
                    "type": "command",
                    "requires_approvals": ["external_generation"],
                    "command": [sys.executable, "-c", f"from pathlib import Path; Path(r'{marker}').write_text('ran')"],
                }
            ]
        )

        blocked = self.run_cli("run", "--config", config)
        self.assertEqual(blocked.returncode, 3, blocked.stderr + blocked.stdout)
        self.assertFalse(marker.exists())

        approved = self.run_cli(
            "approve",
            "--config",
            config,
            "--gate",
            "external_generation",
            "--actor",
            "user",
            "--note",
            "synthetic test approval",
        )
        self.assertEqual(approved.returncode, 0, approved.stderr + approved.stdout)
        resumed = self.run_cli("run", "--config", config)
        self.assertEqual(resumed.returncode, 0, resumed.stderr + resumed.stdout)
        self.assertTrue(marker.exists())

    def test_zero_exit_reported_failure_fails_the_gate(self):
        report = self.root / "gate-report.json"
        writer = self.root / "write_report.py"
        writer.write_text(
            "import json, pathlib\n"
            f"pathlib.Path(r'{report}').write_text(json.dumps({{'status': 'FAIL', 'code': 'GRIP_INVALID'}}))\n",
            encoding="utf-8",
        )
        config = self.write_config(
            [
                {
                    "id": "rig_gate",
                    "type": "command",
                    "command": [sys.executable, str(writer)],
                    "report": {"path": str(report), "status_field": "status", "pass_values": ["PASS"]},
                }
            ]
        )

        result = self.run_cli("run", "--config", config)

        self.assertEqual(result.returncode, 4, result.stderr + result.stdout)
        state = json.loads((self.root / ".3d-pipeline" / "run-state.json").read_text(encoding="utf-8"))
        self.assertEqual(state["stages"]["rig_gate"]["report"]["code"], "GRIP_INVALID")

    def test_nonzero_gate_still_persists_its_machine_report(self):
        report = self.root / "gate-report.json"
        writer = self.root / "write_failed_report.py"
        writer.write_text(
            "import json, pathlib\n"
            f"pathlib.Path(r'{report}').write_text(json.dumps({{'status': 'FAIL', 'code': 'SOURCE_NOT_RIGGABLE'}}))\n"
            "raise SystemExit(9)\n",
            encoding="utf-8",
        )
        config = self.write_config(
            [
                {
                    "id": "asset_gate",
                    "type": "command",
                    "command": [sys.executable, str(writer)],
                    "report": {"path": str(report), "status_field": "status", "pass_values": ["PASS"]},
                }
            ]
        )

        result = self.run_cli("run", "--config", config)

        self.assertEqual(result.returncode, 9)
        state = json.loads((self.root / ".3d-pipeline" / "run-state.json").read_text(encoding="utf-8"))
        self.assertEqual(state["stages"]["asset_gate"]["report"]["code"], "SOURCE_NOT_RIGGABLE")

    def test_changed_input_invalidates_cached_stage_and_downstream(self):
        input_file = self.root / "source.glb"
        input_file.write_text("v1", encoding="utf-8")
        counter = self.root / "counter.txt"
        worker = self.root / "worker.py"
        worker.write_text(
            "from pathlib import Path\n"
            f"p=Path(r'{counter}')\n"
            "p.write_text(str(int(p.read_text()) + 1) if p.exists() else '1')\n",
            encoding="utf-8",
        )
        config = self.write_config(
            [
                {
                    "id": "asset_gate",
                    "type": "command",
                    "inputs": [str(input_file)],
                    "command": [sys.executable, str(worker)],
                },
                {
                    "id": "rig_gate",
                    "type": "command",
                    "command": [sys.executable, "-c", "print('RIG_OK')"],
                },
            ]
        )

        first = self.run_cli("run", "--config", config)
        second = self.run_cli("run", "--config", config)
        input_file.write_text("v2", encoding="utf-8")
        third = self.run_cli("run", "--config", config)

        self.assertEqual((first.returncode, second.returncode, third.returncode), (0, 0, 0))
        self.assertEqual(counter.read_text(encoding="utf-8"), "2")
        self.assertIn("CACHE_INVALIDATED", third.stdout)

    def test_unknown_through_stage_returns_contract_error_without_running(self):
        marker = self.root / "ran.txt"
        config = self.write_config(
            [
                {
                    "id": "asset_gate",
                    "type": "command",
                    "command": [sys.executable, "-c", f"from pathlib import Path; Path(r'{marker}').write_text('ran')"],
                }
            ]
        )

        result = self.run_cli("run", "--config", config, "--through", "missing_gate")

        self.assertEqual(result.returncode, 2)
        self.assertIn("UNKNOWN_STAGE", result.stderr)
        self.assertFalse(marker.exists())

    def test_preflight_is_rechecked_on_every_run(self):
        config = self.root / "pipeline.json"
        config.write_text(
            json.dumps(
                {
                    "schema_version": "1.4",
                    "project": {
                        "name": "preflight-test",
                        "quality": "Q1",
                        "duration_seconds": 5,
                        "fps": 30,
                        "resolution": [1080, 1920],
                    },
                    "tools": {"python": {"path": sys.executable, "version_args": ["--version"]}},
                    "stages": [{"id": "preflight", "type": "preflight"}],
                }
            ),
            encoding="utf-8",
        )

        first = self.run_cli("run", "--config", config)
        second = self.run_cli("run", "--config", config)

        self.assertEqual((first.returncode, second.returncode), (0, 0))
        self.assertNotIn("STAGE_SKIPPED=preflight", second.stdout)
        state = json.loads((self.root / ".3d-pipeline" / "run-state.json").read_text(encoding="utf-8"))
        self.assertEqual(state["stages"]["preflight"]["attempts"], 2)

    def test_always_run_command_stage_is_not_reused_from_cache(self):
        counter = self.root / "mcp-probes.txt"
        worker = self.root / "probe.py"
        worker.write_text(
            "from pathlib import Path\n"
            f"p=Path(r'{counter}')\n"
            "p.write_text(str(int(p.read_text()) + 1) if p.exists() else '1')\n",
            encoding="utf-8",
        )
        config = self.write_config(
            [
                {
                    "id": "blender_mcp_gate",
                    "type": "command",
                    "always_run": True,
                    "command": [sys.executable, str(worker)],
                }
            ]
        )

        first = self.run_cli("run", "--config", config)
        second = self.run_cli("run", "--config", config)

        self.assertEqual((first.returncode, second.returncode), (0, 0))
        self.assertEqual(counter.read_text(encoding="utf-8"), "2")

    def test_configure_mixamo_builds_real_blender_handoff_stage(self):
        base = self.root / "rigged-character.fbx"
        motion = self.root / "walk.fbx"
        base.write_bytes(b"character")
        motion.write_bytes(b"motion")
        mixamo = self.root / "mixamo.json"
        mixamo.write_text(
            json.dumps(
                {
                    "base_character": str(base),
                    "motions": [{"path": str(motion), "name": "Walk"}],
                    "output_blend": str(self.root / "handoff.blend"),
                    "output_glb": str(self.root / "handoff.glb"),
                    "output_report": str(self.root / "handoff.json"),
                }
            ),
            encoding="utf-8",
        )
        config = self.write_config(
            [
                {"id": "asset_gate", "type": "command", "configured": False, "command": []},
                {"id": "rig_gate", "type": "command", "configured": False, "command": []},
            ]
        )
        payload = json.loads(config.read_text(encoding="utf-8"))
        payload["tools"] = {"blender": {"path": sys.executable, "version_args": ["--version"]}}
        config.write_text(json.dumps(payload), encoding="utf-8")

        result = self.run_cli("configure-mixamo", "--config", config, "--mixamo-config", mixamo)

        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        updated = json.loads(config.read_text(encoding="utf-8"))
        ids = [stage["id"] for stage in updated["stages"]]
        self.assertEqual(ids, ["asset_gate", "mixamo_handoff", "rig_gate"])
        stage = updated["stages"][1]
        self.assertTrue(stage["configured"])
        self.assertEqual(stage["inputs"], [str(mixamo), str(base), str(motion)])
        self.assertEqual(stage["outputs"], [str(self.root / "handoff.blend"), str(self.root / "handoff.glb"), str(self.root / "handoff.json")])
        self.assertEqual(stage["report"]["path"], str(self.root / "handoff.json"))
        self.assertEqual(stage["command"][0], sys.executable)
        self.assertIn("blender_mixamo_handoff.py", stage["command"][4])


if __name__ == "__main__":
    unittest.main()
