import json
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "blender_mixamo_handoff.py"


def find_blender():
    direct = Path("C:/Program Files/Blender Foundation/Blender 5.2/blender.exe")
    return str(direct) if direct.is_file() else shutil.which("blender")


class BlenderMixamoHandoffTests(unittest.TestCase):
    def setUp(self):
        self.blender = find_blender()
        if not self.blender:
            self.skipTest("Blender is unavailable")
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)

    def tearDown(self):
        self.temp_dir.cleanup()

    def run_blender(self, *args):
        return subprocess.run(
            [self.blender, "--background", "--factory-startup", *map(str, args)],
            text=True,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            timeout=60,
        )

    def test_fbx_motion_is_mapped_saved_and_exported_for_godot(self):
        target = self.root / "target.blend"
        motion = self.root / "walk.fbx"
        builder = self.root / "build_fixture.py"
        builder.write_text(
            "import bpy,sys\n"
            "from pathlib import Path\n"
            "root=Path(sys.argv[sys.argv.index('--')+1])\n"
            "def clear():\n"
            " bpy.ops.object.mode_set(mode='OBJECT') if bpy.context.object and bpy.context.object.mode!='OBJECT' else None\n"
            " bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)\n"
            " for a in list(bpy.data.actions): bpy.data.actions.remove(a)\n"
            "def rig(name,names):\n"
            " data=bpy.data.armatures.new(name+'Data'); obj=bpy.data.objects.new(name,data); bpy.context.collection.objects.link(obj)\n"
            " bpy.context.view_layer.objects.active=obj; obj.select_set(True); bpy.ops.object.mode_set(mode='EDIT')\n"
            " for i,n in enumerate(names):\n"
            "  b=data.edit_bones.new(n); b.head=(0,0,float(i)); b.tail=(0,0,float(i)+0.8)\n"
            " bpy.ops.object.mode_set(mode='POSE'); return obj\n"
            "clear(); s=rig('MotionRig',['mixamorig:Hips','mixamorig:LeftArm','mixamorig:RightArm'])\n"
            "a=bpy.data.actions.new('SourceWalk'); s.animation_data_create(); s.animation_data.action=a\n"
            "h=s.pose.bones['mixamorig:Hips']; l=s.pose.bones['mixamorig:LeftArm']; r=s.pose.bones['mixamorig:RightArm']\n"
            "for p in (l,r): p.rotation_mode='XYZ'\n"
            "h.location.x=0; h.keyframe_insert('location',frame=1); h.location.x=2; h.keyframe_insert('location',frame=10)\n"
            "l.rotation_euler.z=0; l.keyframe_insert('rotation_euler',frame=1); l.rotation_euler.z=.5; l.keyframe_insert('rotation_euler',frame=10)\n"
            "r.rotation_euler.z=0; r.keyframe_insert('rotation_euler',frame=1); r.rotation_euler.z=-.5; r.keyframe_insert('rotation_euler',frame=10)\n"
            "bpy.ops.object.mode_set(mode='OBJECT'); bpy.ops.object.select_all(action='DESELECT'); s.select_set(True); bpy.context.view_layer.objects.active=s\n"
            "bpy.ops.export_scene.fbx(filepath=str(root/'walk.fbx'),use_selection=True,add_leaf_bones=False,bake_anim=True)\n"
            "clear(); t=rig('TargetRig',['Hips','LeftArm','RightArm']); bpy.ops.object.mode_set(mode='OBJECT')\n"
            "old=bpy.data.actions.new('OldPose'); old.use_fake_user=True; t.animation_data_create(); t.animation_data.action=old\n"
            "t.pose.bones['LeftArm'].rotation_mode='XYZ'; t.pose.bones['LeftArm'].rotation_euler.z=.2; t.pose.bones['LeftArm'].keyframe_insert('rotation_euler',frame=1)\n"
            "bpy.ops.wm.save_as_mainfile(filepath=str(root/'target.blend'))\n",
            encoding="utf-8",
        )
        built = self.run_blender("--python", builder, "--", self.root)
        self.assertEqual(built.returncode, 0, built.stderr + built.stdout)

        output_blend = self.root / "handoff.blend"
        output_glb = self.root / "handoff.glb"
        report = self.root / "handoff.json"
        config = self.root / "mixamo.json"
        config.write_text(
            json.dumps(
                {
                    "base_character": str(target),
                    "target_armature": "TargetRig",
                    "required_bones": ["Hips", "LeftArm", "RightArm"],
                    "motions": [
                        {"path": str(motion), "name": "Walk", "root_motion": "in_place"}
                    ],
                    "output_blend": str(output_blend),
                    "output_glb": str(output_glb),
                    "output_report": str(report),
                }
            ),
            encoding="utf-8",
        )

        handed_off = self.run_blender("--python", SCRIPT, "--", "--config", config)

        self.assertEqual(handed_off.returncode, 0, handed_off.stderr + handed_off.stdout)
        self.assertNotIn("Animation target", handed_off.stdout + handed_off.stderr)
        self.assertTrue(report.is_file(), handed_off.stderr + handed_off.stdout)
        payload = json.loads(report.read_text(encoding="utf-8"))
        self.assertEqual(payload["status"], "PASS")
        self.assertEqual(payload["motions"][0]["name"], "Walk")
        self.assertEqual(payload["removed_existing_target_actions"], ["OldPose"])
        self.assertGreaterEqual(payload["motions"][0]["mapped_curve_count"], 2)
        self.assertLessEqual(payload["motions"][0]["max_rest_axis_angle_degrees"], 1.0)
        self.assertLessEqual(payload["motions"][0]["max_rest_basis_angle_degrees"], 1.0)
        self.assertGreater(payload["motions"][0]["max_pose_rotation_degrees"], 0.1)
        self.assertTrue(output_blend.is_file())
        self.assertTrue(output_glb.is_file())

        inspector = self.root / "inspect.py"
        inspector.write_text(
            "import bpy,json\n"
            "assert 'OldPose' not in bpy.data.actions\n"
            "o=bpy.data.objects['TargetRig']; a=bpy.data.actions['Walk']; o.animation_data_create(); o.animation_data.action=a\n"
            "bpy.context.scene.frame_set(1); x1=o.pose.bones['Hips'].location.x; m1=o.pose.bones['LeftArm'].matrix_basis.copy()\n"
            "bpy.context.scene.frame_set(10); x2=o.pose.bones['Hips'].location.x; m2=o.pose.bones['LeftArm'].matrix_basis.copy()\n"
            "delta=(m1.inverted()@m2).to_quaternion().angle\n"
            "print('HANDOFF_VALUES='+json.dumps({'x1':x1,'x2':x2,'rotation_delta':delta}))\n",
            encoding="utf-8",
        )
        inspected = self.run_blender(output_blend, "--python", inspector)
        self.assertEqual(inspected.returncode, 0, inspected.stderr + inspected.stdout)
        line = next(item for item in inspected.stdout.splitlines() if item.startswith("HANDOFF_VALUES="))
        values = json.loads(line.split("=", 1)[1])
        self.assertAlmostEqual(values["x1"], 0.0, places=4)
        self.assertAlmostEqual(values["x2"], 0.0, places=4)
        self.assertGreater(values["rotation_delta"], 0.1)


if __name__ == "__main__":
    unittest.main()
