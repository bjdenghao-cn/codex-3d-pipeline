import sys
import unittest
from pathlib import Path


SCRIPTS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SCRIPTS))


class MixamoMappingTests(unittest.TestCase):
    def module(self):
        try:
            import mixamo_mapping
        except ModuleNotFoundError as exc:
            self.fail(f"Mixamo mapping module is missing: {exc}")
        return mixamo_mapping

    def test_prefix_independent_mapping_preserves_left_and_right(self):
        module = self.module()

        mapping = module.build_bone_map(
            ["mixamorig:Hips", "mixamorig:LeftArm", "mixamorig:RightArm"],
            ["Hips", "LeftArm", "RightArm"],
        )

        self.assertEqual(
            mapping,
            {
                "mixamorig:Hips": "Hips",
                "mixamorig:LeftArm": "LeftArm",
                "mixamorig:RightArm": "RightArm",
            },
        )

    def test_explicit_left_to_right_mapping_is_rejected(self):
        module = self.module()

        with self.assertRaises(module.MappingError):
            module.build_bone_map(
                ["mixamorig:LeftHand"],
                ["RightHand"],
                {"mixamorig:LeftHand": "RightHand"},
            )

    def test_action_data_path_is_remapped_to_target_bone(self):
        module = self.module()

        remapped = module.remap_data_path(
            'pose.bones["mixamorig:LeftForeArm"].rotation_quaternion',
            {"mixamorig:LeftForeArm": "forearm.L"},
        )

        self.assertEqual(remapped, 'pose.bones["forearm.L"].rotation_quaternion')

    def test_in_place_root_motion_zeroes_horizontal_translation_only(self):
        module = self.module()

        self.assertEqual(module.remap_location_value(3.5, 0, "in_place", 2.0), 0.0)
        self.assertEqual(module.remap_location_value(-1.5, 1, "in_place", 2.0), 0.0)
        self.assertEqual(module.remap_location_value(1.25, 2, "in_place", 2.0), 2.5)
        self.assertEqual(module.remap_location_value(1.25, 0, "keep", 2.0), 2.5)

    def test_rest_axis_angle_detects_flipped_bone(self):
        module = self.module()

        self.assertAlmostEqual(module.axis_angle_degrees((1, 0, 0), (1, 0, 0)), 0.0)
        self.assertAlmostEqual(module.axis_angle_degrees((1, 0, 0), (-1, 0, 0)), 180.0)


if __name__ == "__main__":
    unittest.main()
