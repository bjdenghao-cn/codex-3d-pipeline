import json
import socket
import subprocess
import sys
import tempfile
import threading
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "blender_mcp_gate.py"


class FakeBlenderMcpServer:
    def __init__(self, protocol=5):
        self.protocol = protocol
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.bind(("127.0.0.1", 0))
        self.socket.listen(5)
        self.port = self.socket.getsockname()[1]
        self.thread = threading.Thread(target=self._serve, daemon=True)
        self.thread.start()

    def _serve(self):
        for _ in range(2):
            connection, _ = self.socket.accept()
            with connection:
                request = json.loads(connection.recv(8192).decode("utf-8"))
                if request["type"] == "get_addon_info":
                    result = {
                        "name": "Blender MCP",
                        "addon_version": [1, 6],
                        "protocol_version": self.protocol,
                        "capabilities": ["get_addon_info", "get_scene_info"],
                        "blender_version": "5.2.0 LTS",
                    }
                else:
                    result = {"name": "Scene", "object_count": 1, "objects": []}
                connection.sendall(json.dumps({"status": "success", "result": result}).encode("utf-8"))
        self.socket.close()


class BlenderMcpGateTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)

    def tearDown(self):
        self.temp_dir.cleanup()

    def run_gate(self, *args):
        return subprocess.run(
            [sys.executable, str(SCRIPT), *map(str, args)],
            text=True,
            capture_output=True,
            encoding="utf-8",
        )

    def test_live_handshake_and_scene_query_pass(self):
        server = FakeBlenderMcpServer()
        report = self.root / "mcp.json"

        result = self.run_gate(
            "--host", "127.0.0.1",
            "--port", server.port,
            "--timeout", "2",
            "--expected-protocol", "5",
            "--output", report,
        )

        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        payload = json.loads(report.read_text(encoding="utf-8"))
        self.assertEqual(payload["status"], "PASS")
        self.assertEqual(payload["addon"]["protocol_version"], 5)
        self.assertEqual(payload["scene"]["object_count"], 1)

    def test_protocol_mismatch_fails_with_machine_code(self):
        server = FakeBlenderMcpServer(protocol=4)
        report = self.root / "mcp.json"

        result = self.run_gate(
            "--host", "127.0.0.1",
            "--port", server.port,
            "--timeout", "2",
            "--expected-protocol", "5",
            "--output", report,
        )

        self.assertNotEqual(result.returncode, 0)
        payload = json.loads(report.read_text(encoding="utf-8"))
        self.assertEqual(payload["status"], "FAIL")
        self.assertEqual(payload["code"], "MCP_PROTOCOL_MISMATCH")

    def test_start_if_needed_launches_gui_command_then_connects(self):
        listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listener.bind(("127.0.0.1", 0))
        port = listener.getsockname()[1]
        listener.close()
        helper = self.root / "fake_blender.py"
        helper.write_text(
            "import json,socket,sys\n"
            "s=socket.socket(); s.bind(('127.0.0.1',int(sys.argv[1]))); s.listen(5)\n"
            "for _ in range(2):\n"
            " c,_=s.accept(); q=json.loads(c.recv(8192).decode())\n"
            " r={'name':'Blender MCP','addon_version':[1,6],'protocol_version':5,'capabilities':['get_addon_info','get_scene_info'],'blender_version':'5.2.0 LTS'} if q['type']=='get_addon_info' else {'name':'Scene','object_count':0,'objects':[]}\n"
            " c.sendall(json.dumps({'status':'success','result':r}).encode()); c.close()\n"
            "s.close()\n",
            encoding="utf-8",
        )
        report = self.root / "mcp.json"

        result = self.run_gate(
            "--host", "127.0.0.1",
            "--port", port,
            "--timeout", "5",
            "--expected-protocol", "5",
            "--start-if-needed",
            "--blender", sys.executable,
            "--blender-arg", helper,
            "--blender-arg", str(port),
            "--output", report,
        )

        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        payload = json.loads(report.read_text(encoding="utf-8"))
        self.assertTrue(payload["started_process"])
        self.assertEqual(payload["status"], "PASS")


if __name__ == "__main__":
    unittest.main()
