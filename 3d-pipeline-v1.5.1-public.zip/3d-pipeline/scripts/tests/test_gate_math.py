import sys
import unittest
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from gate_math import coerce_frame, connected_components, evaluate_grip_side, max_edge_stretch


class GateMathTests(unittest.TestCase):
    def test_integral_json_frame_is_coerced_for_blender(self):
        self.assertEqual(coerce_frame(30.0), 30)

    def test_fractional_frame_is_rejected_instead_of_silently_rounded(self):
        with self.assertRaisesRegex(ValueError, "whole frame"):
            coerce_frame(30.5)

    def test_connected_components_exposes_fragmented_hand_shells(self):
        selected = set(range(9))
        edges = [(0, 1), (1, 2), (3, 4), (5, 6), (7, 8)]

        sizes = connected_components(selected, edges)

        self.assertEqual(sizes, [3, 2, 2, 2])

    def test_grip_fails_when_index_is_69_4_mm_from_handle_surface(self):
        centre = (0.0, 0.0, 0.0)
        radius = 0.026
        points = {
            "thumb": [(-radius, 0.0, 0.0)],
            "index": [(radius + 0.0694, 0.0, 0.0)],
            "middle": [(radius, 0.0, 0.0)],
            "ring": [(radius, 0.0, 0.0)],
            "pinky": [(radius, 0.0, 0.0)],
        }

        result = evaluate_grip_side(
            hand_points=[(0.0, radius, 0.0)],
            digit_points=points,
            centre=centre,
            axis=(0.0, 0.0, 1.0),
            half_length=0.085,
            radius=radius,
            contact_tolerance=0.014,
            max_palm_penetration=0.008,
            max_hand_target_distance=0.12,
            max_thumb_opposition_dot=-0.10,
        )

        self.assertEqual(result["status"], "FAIL")
        self.assertIn("FINGER_MISSES_GRIP:index", result["failure_codes"])
        self.assertAlmostEqual(result["digit_contact_surface_errors_m"]["index"], 0.0694, places=4)

    def test_grip_fails_for_non_opposing_thumb_and_palm_penetration(self):
        radius = 0.026
        result = evaluate_grip_side(
            hand_points=[(0.0, 0.0, 0.0)],
            digit_points={
                "thumb": [(radius, 0.0, 0.0)],
                "index": [(radius, 0.0, 0.0)],
                "middle": [(radius, 0.0, 0.0)],
                "ring": [(radius, 0.0, 0.0)],
                "pinky": [(radius, 0.0, 0.0)],
            },
            centre=(0.0, 0.0, 0.0),
            axis=(0.0, 0.0, 1.0),
            half_length=0.085,
            radius=radius,
            contact_tolerance=0.014,
            max_palm_penetration=0.008,
            max_hand_target_distance=0.12,
            max_thumb_opposition_dot=-0.10,
        )

        self.assertIn("THUMB_NOT_OPPOSING", result["failure_codes"])
        self.assertIn("PALM_PENETRATION", result["failure_codes"])

    def test_edge_stretch_detects_weight_tearing(self):
        rest = [(0.0, 0.0, 0.0), (0.01, 0.0, 0.0), (0.02, 0.0, 0.0)]
        posed = [(0.0, 0.0, 0.0), (0.30, 0.0, 0.0), (0.31, 0.0, 0.0)]

        result = max_edge_stretch(rest, posed, [(0, 1), (1, 2)])

        self.assertAlmostEqual(result["max_ratio"], 30.0, places=5)
        self.assertEqual(result["edge"], [0, 1])


if __name__ == "__main__":
    unittest.main()
