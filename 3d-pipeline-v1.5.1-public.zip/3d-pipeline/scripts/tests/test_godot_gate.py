import sys
import unittest
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from godot_project_gate import build_report, validate_scene_semantics


class GodotGateTests(unittest.TestCase):
    def test_zero_exit_without_runtime_marker_is_a_failure(self):
        report = build_report(0, "scene loaded", "", "GODOT_GATE_OK")

        self.assertEqual(report["status"], "FAIL")
        self.assertEqual(report["failure_codes"][0]["code"], "GODOT_SUCCESS_MARKER_MISSING")

    def test_nonzero_exit_with_marker_is_still_a_failure(self):
        report = build_report(7, "GODOT_GATE_OK", "crash", "GODOT_GATE_OK")

        self.assertEqual(report["status"], "FAIL")
        self.assertEqual(report["failure_codes"][0], {"code": "GODOT_VALIDATOR_EXIT", "exit_code": 7})

    def test_zero_exit_and_runtime_marker_pass(self):
        report = build_report(0, "GODOT_GATE_OK\n", "", "GODOT_GATE_OK")

        self.assertEqual(report["status"], "PASS")
        self.assertEqual(report["failure_codes"], [])

    def test_rejects_standing_driver_and_reversed_hero_vehicle(self):
        scene = {
            "hero_assets": {"vehicle": {"source": "procedural", "formal": True}},
            "environment": {"formal": False, "q0_visible": True, "ground_material": "flat", "depth_layers": 1, "unique_setpieces": 0, "repetition_score": 0.9, "empty_screen_ratio": 0.8, "camera_path_coverage": 0.2},
            "vehicles": [{"role": "hero", "continuous_forward": True, "forward_dot": -1.0}],
            "riders": [{"role": "driver", "posture": "standing"}],
            "vfx": [],
        }
        codes = {failure["code"] for failure in validate_scene_semantics(scene, {})}
        self.assertIn("HERO_ASSET_SOURCE_UNAPPROVED", codes)
        self.assertIn("VEHICLE_FORWARD_AXIS_MISMATCH", codes)
        self.assertIn("DRIVER_NOT_SEATED", codes)

    def test_rejects_opaque_sphere_smoke(self):
        scene = {
            "hero_assets": {"vehicle": {"source": "generated_3d", "model": "hunyuan-v3.1", "selection_rationale": "realistic textured vehicle from one clear reference", "formal": True}},
            "environment": {"formal": True, "q0_visible": False, "ground_material": "pbr", "depth_layers": 3, "unique_setpieces": 3, "repetition_score": 0.2, "empty_screen_ratio": 0.3, "camera_path_coverage": 0.95},
            "vehicles": [{"role": "hero", "continuous_forward": True, "forward_dot": 0.999}],
            "riders": [{
                "role": "driver", "posture": "seated", "seat_contact_m": 0.03,
                "hip_flexion_deg": 88, "knee_flexion_deg": 96,
                "left_hand_target_m": 0.03, "right_hand_target_m": 0.03,
                "left_foot_target_m": 0.06, "right_foot_target_m": 0.05,
            }],
            "vfx": [{
                "kind": "explosion", "representation": "opaque_primitive_stack",
                "soft_alpha": False, "layers": ["fire", "smoke"],
            }],
        }
        codes = {failure["code"] for failure in validate_scene_semantics(scene, {})}
        self.assertIn("VFX_OPAQUE_PRIMITIVE_SMOKE", codes)
        self.assertIn("VFX_LAYERS_MISSING", codes)

    def test_formal_vehicle_seated_driver_and_layered_vfx_pass(self):
        scene = {
            "hero_assets": {"vehicle": {"source": "generated_3d", "model": "tripo-v3.1", "selection_rationale": "high precision geometry from image references", "formal": True}},
            "environment": {"formal": True, "q0_visible": False, "ground_material": "pbr", "depth_layers": 3, "unique_setpieces": 3, "repetition_score": 0.2, "empty_screen_ratio": 0.3, "camera_path_coverage": 0.95},
            "vehicles": [{"role": "hero", "continuous_forward": True, "forward_dot": 0.999}],
            "riders": [{
                "role": "driver", "posture": "seated", "seat_contact_m": 0.03,
                "hip_flexion_deg": 88, "knee_flexion_deg": 96,
                "left_hand_target_m": 0.03, "right_hand_target_m": 0.03,
                "left_foot_target_m": 0.06, "right_foot_target_m": 0.05,
            }],
            "vfx": [{
                "kind": "explosion", "representation": "soft_billboard_particles",
                "soft_alpha": True, "layers": ["flash", "fire", "smoke", "dust", "debris"],
                "smoke_rise_mps": 1.8, "opacity_decay": True, "wind_response": True,
                "max_strong_occlusion_frames": 6, "white_clip_ratio": 0.02,
            }],
        }
        self.assertEqual(validate_scene_semantics(scene, {}), [])

    def test_rejects_q0_flat_repetitive_environment(self):
        scene = {
            "hero_assets": {"vehicle": {"source": "generated_3d", "model": "rodin-gen-2.5", "selection_rationale": "hard surface candidate with explicit geometry budget", "formal": True}},
            "environment": {"formal": False, "q0_visible": True, "ground_material": "flat", "depth_layers": 1, "unique_setpieces": 0, "repetition_score": 0.9, "empty_screen_ratio": 0.8, "camera_path_coverage": 0.2},
            "vehicles": [{"role": "hero", "continuous_forward": True, "forward_dot": 0.999}],
            "riders": [{
                "role": "driver", "posture": "seated", "seat_contact_m": 0.03,
                "hip_flexion_deg": 88, "knee_flexion_deg": 96,
                "left_hand_target_m": 0.03, "right_hand_target_m": 0.03,
                "left_foot_target_m": 0.06, "right_foot_target_m": 0.05,
            }],
            "vfx": [],
        }
        codes = {failure["code"] for failure in validate_scene_semantics(scene, {})}
        self.assertIn("ENVIRONMENT_NOT_FORMAL", codes)
        self.assertIn("Q0_VISIBLE_IN_FORMAL_SCENE", codes)
        self.assertIn("ENVIRONMENT_DEPTH_INSUFFICIENT", codes)
        self.assertIn("ENVIRONMENT_REPETITION_EXCESSIVE", codes)

    def test_all_supported_generation_routes_can_be_formal(self):
        base = {
            "environment": {"formal": True, "q0_visible": False, "ground_material": "pbr", "depth_layers": 3, "unique_setpieces": 3, "repetition_score": 0.2, "empty_screen_ratio": 0.3, "camera_path_coverage": 0.95},
            "vehicles": [{"role": "hero", "continuous_forward": True, "forward_dot": 0.999}],
            "riders": [{
                "role": "driver", "posture": "seated", "seat_contact_m": 0.03,
                "hip_flexion_deg": 88, "knee_flexion_deg": 96,
                "left_hand_target_m": 0.03, "right_hand_target_m": 0.03,
                "left_foot_target_m": 0.06, "right_foot_target_m": 0.05,
            }],
            "vfx": [],
        }
        for model in ("hunyuan-v3.1", "tripo-v3.1", "tripo-P1", "rodin-gen-2.5"):
            with self.subTest(model=model):
                scene = dict(base)
                scene["hero_assets"] = {"vehicle": {
                    "source": "generated_3d", "model": model,
                    "selection_rationale": "project-specific asset routing decision", "formal": True,
                }}
                self.assertEqual(validate_scene_semantics(scene, {}), [])


if __name__ == "__main__":
    unittest.main()
