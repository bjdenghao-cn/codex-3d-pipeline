"""Blender-side source-asset gate for riggability and Q1/Q2 readiness."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import bpy
from mathutils import Vector


sys.path.insert(0, str(Path(__file__).resolve().parent))
from gate_math import connected_components


def cli_args() -> argparse.Namespace:
    raw = sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else []
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--output", required=True)
    return parser.parse_args(raw)


def load_input(path: Path) -> None:
    suffix = path.suffix.lower()
    if suffix == ".blend":
        bpy.ops.wm.open_mainfile(filepath=str(path))
        return
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if suffix in {".glb", ".gltf"}:
        bpy.ops.import_scene.gltf(filepath=str(path))
    elif suffix == ".fbx":
        bpy.ops.import_scene.fbx(filepath=str(path))
    else:
        raise ValueError(f"unsupported asset format: {suffix}")


def normalized_coordinates(meshes, target_height: float) -> dict[str, list[tuple[float, float, float]]]:
    world_points = [obj.matrix_world @ vertex.co for obj in meshes for vertex in obj.data.vertices]
    if not world_points:
        raise ValueError("asset contains no mesh vertices")
    low = Vector(tuple(min(point[axis] for point in world_points) for axis in range(3)))
    high = Vector(tuple(max(point[axis] for point in world_points) for axis in range(3)))
    height = high.z - low.z
    if height <= 1e-8:
        raise ValueError("asset has zero height")
    scale = target_height / height
    centre = (low + high) * 0.5
    result = {}
    for obj in meshes:
        coords = []
        for vertex in obj.data.vertices:
            point = obj.matrix_world @ vertex.co
            coords.append(((point.x - centre.x) * scale, (point.y - centre.y) * scale, (point.z - low.z) * scale))
        result[obj.name] = coords
    return result


def count_non_manifold_edges(obj) -> int:
    uses = {tuple(sorted(edge.vertices)): 0 for edge in obj.data.edges}
    for polygon in obj.data.polygons:
        for key in polygon.edge_keys:
            uses[tuple(sorted(key))] = uses.get(tuple(sorted(key)), 0) + 1
    return sum(1 for count in uses.values() if count != 2)


def main() -> int:
    args = cli_args()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    failures: list[dict[str, object]] = []
    report: dict[str, object] = {"status": "FAIL", "gate": "asset_gate", "failure_codes": failures}
    try:
        input_path = Path(args.input).resolve()
        config = json.loads(Path(args.config).read_text(encoding="utf-8"))
        load_input(input_path)
        all_meshes = [obj for obj in bpy.context.scene.objects if obj.type == "MESH"]
        mesh_name = config.get("mesh_name")
        meshes = [bpy.data.objects.get(mesh_name)] if mesh_name else all_meshes
        meshes = [obj for obj in meshes if obj is not None and obj.type == "MESH"]
        if not meshes:
            failures.append({"code": "MESH_MISSING", "mesh_name": mesh_name})
            raise RuntimeError("configured mesh was not found")

        vertices = sum(len(obj.data.vertices) for obj in meshes)
        triangles = 0
        materials = set()
        non_manifold_edges = 0
        for obj in meshes:
            obj.data.calc_loop_triangles()
            triangles += len(obj.data.loop_triangles)
            materials.update(material.name for material in obj.data.materials if material)
            non_manifold_edges += count_non_manifold_edges(obj)
        images = {image.name for image in bpy.data.images if image.source != "VIEWER"}
        report.update(
            {
                "input": str(input_path),
                "mesh_objects": [obj.name for obj in meshes],
                "vertices": vertices,
                "triangles": triangles,
                "materials": len(materials),
                "images": len(images),
                "non_manifold_edges": non_manifold_edges,
            }
        )

        thresholds = config.get("thresholds", {})
        for key, actual, default_direction in (
            ("min_vertices", vertices, "min"),
            ("min_triangles", triangles, "min"),
            ("min_materials", len(materials), "min"),
            ("min_images", len(images), "min"),
            ("max_triangles", triangles, "max"),
            ("max_non_manifold_edges", non_manifold_edges, "max"),
        ):
            if key not in thresholds:
                continue
            limit = thresholds[key]
            invalid = actual < limit if default_direction == "min" else actual > limit
            if invalid:
                failures.append({"code": key.upper(), "actual": actual, "limit": limit})

        quality = config.get("quality", "Q1")
        hand_regions = config.get("hand_regions", [])
        if quality == "Q2" and len(hand_regions) < 2:
            failures.append({"code": "Q2_HAND_REGIONS_REQUIRED", "actual": len(hand_regions)})
        coords_by_mesh = normalized_coordinates(meshes, float(config.get("target_height_m", 1.78)))
        hand_reports = []
        for region in hand_regions:
            region_mesh = bpy.data.objects.get(region.get("mesh_name", mesh_name)) if region.get("mesh_name", mesh_name) else meshes[0]
            if region_mesh not in meshes:
                failures.append({"code": "HAND_REGION_MESH_MISSING", "id": region.get("id")})
                continue
            minimum = region["min"]
            maximum = region["max"]
            coords = coords_by_mesh[region_mesh.name]
            selected = {
                index
                for index, point in enumerate(coords)
                if all(float(minimum[axis]) <= point[axis] <= float(maximum[axis]) for axis in range(3))
            }
            sizes = connected_components(selected, [edge.vertices for edge in region_mesh.data.edges])
            min_component_vertices = int(region.get("min_component_vertices", 8))
            significant = [size for size in sizes if size >= min_component_vertices]
            hand_report = {
                "id": region.get("id"),
                "selected_vertices": len(selected),
                "total_components": len(sizes),
                "significant_components": len(significant),
                "largest_components": sizes[:10],
            }
            hand_reports.append(hand_report)
            if len(selected) < int(region.get("min_vertices", 1)):
                failures.append({"code": "HAND_REGION_EMPTY", "id": region.get("id"), "actual": len(selected)})
            if "max_total_components" in region and len(sizes) > int(region["max_total_components"]):
                failures.append({"code": "HAND_FRAGMENTED_SHELLS", "id": region.get("id"), "actual": len(sizes), "limit": region["max_total_components"]})
            if "max_significant_components" in region and len(significant) > int(region["max_significant_components"]):
                failures.append({"code": "HAND_SIGNIFICANT_SHELLS", "id": region.get("id"), "actual": len(significant), "limit": region["max_significant_components"]})
        report["hand_regions"] = hand_reports
    except Exception as exc:
        if not failures:
            failures.append({"code": "ASSET_GATE_EXCEPTION", "message": str(exc)})

    report["status"] = "FAIL" if failures else "PASS"
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
