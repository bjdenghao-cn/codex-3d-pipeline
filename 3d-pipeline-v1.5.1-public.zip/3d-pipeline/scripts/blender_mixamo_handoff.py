#!/usr/bin/env python3
"""Import local Mixamo FBX actions, map them onto a target rig, and export GLB."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import sys
from pathlib import Path
from typing import Any, Iterable

import bpy

sys.path.insert(0, str(Path(__file__).resolve().parent))
from mixamo_mapping import (
    MappingError,
    axis_angle_degrees,
    build_bone_map,
    remap_data_path,
    remap_location_value,
)


_BONE_PATH = re.compile(r'pose\.bones\[(["\'])(.+?)\1\]')


class HandoffError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def resolve(base: Path, value: str) -> Path:
    path = Path(os.path.expandvars(value))
    return path.resolve() if path.is_absolute() else (base / path).resolve()


def write_report(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise HandoffError("CONFIG_NOT_FOUND", str(path)) from exc
    except json.JSONDecodeError as exc:
        raise HandoffError("CONFIG_INVALID", str(exc)) from exc
    if not isinstance(value, dict):
        raise HandoffError("CONFIG_INVALID", "configuration root must be an object")
    return value


def clear_scene() -> None:
    if bpy.context.object and bpy.context.object.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)


def import_asset(path: Path) -> list[bpy.types.Object]:
    if not path.is_file():
        raise HandoffError("INPUT_NOT_FOUND", str(path))
    before = set(bpy.data.objects)
    suffix = path.suffix.lower()
    if suffix == ".fbx":
        bpy.ops.import_scene.fbx(filepath=str(path), use_anim=True)
    elif suffix in {".glb", ".gltf"}:
        bpy.ops.import_scene.gltf(filepath=str(path))
    else:
        raise HandoffError("UNSUPPORTED_INPUT", f"unsupported asset type: {path.suffix}")
    return [obj for obj in bpy.data.objects if obj not in before]


def open_character(path: Path) -> None:
    if not path.is_file():
        raise HandoffError("BASE_CHARACTER_NOT_FOUND", str(path))
    if path.suffix.lower() == ".blend":
        bpy.ops.wm.open_mainfile(filepath=str(path))
    else:
        clear_scene()
        import_asset(path)


def find_armature(objects: Iterable[bpy.types.Object], requested: str | None, role: str) -> bpy.types.Object:
    armatures = [obj for obj in objects if obj.type == "ARMATURE"]
    if requested:
        matches = [obj for obj in armatures if obj.name == requested]
        if len(matches) != 1:
            raise HandoffError(f"{role.upper()}_ARMATURE_NOT_FOUND", requested)
        return matches[0]
    if len(armatures) != 1:
        raise HandoffError(
            f"{role.upper()}_ARMATURE_AMBIGUOUS",
            f"expected one armature, found {[obj.name for obj in armatures]}",
        )
    return armatures[0]


def clear_existing_target_animation(target: bpy.types.Object) -> list[str]:
    """Remove base-file armature actions so the configured motion set is deterministic."""
    animation_data = target.animation_data
    if animation_data is None:
        return []
    actions: set[bpy.types.Action] = set()
    if animation_data.action is not None:
        actions.add(animation_data.action)
    for track in animation_data.nla_tracks:
        for strip in track.strips:
            if strip.action is not None:
                actions.add(strip.action)
    names = sorted(action.name for action in actions)
    target.animation_data_clear()
    for action in actions:
        if action.name in bpy.data.actions:
            bpy.data.actions.remove(action)
    return names


def action_fcurves(action: bpy.types.Action) -> list[bpy.types.FCurve]:
    legacy = getattr(action, "fcurves", None)
    if legacy is not None:
        return list(legacy)
    curves: list[bpy.types.FCurve] = []
    for layer in action.layers:
        for strip in layer.strips:
            for channelbag in getattr(strip, "channelbags", []):
                curves.extend(channelbag.fcurves)
    return curves


def source_bone_from_path(data_path: str) -> str | None:
    match = _BONE_PATH.search(data_path)
    return match.group(2) if match else None


def choose_source_action(source: bpy.types.Object, new_actions: list[bpy.types.Action]) -> bpy.types.Action:
    if source.animation_data and source.animation_data.action:
        return source.animation_data.action
    candidates = [action for action in new_actions if any(source_bone_from_path(c.data_path) for c in action_fcurves(action))]
    if len(candidates) != 1:
        raise HandoffError(
            "SOURCE_ACTION_AMBIGUOUS",
            f"expected one armature action, found {[action.name for action in candidates]}",
        )
    return candidates[0]


def copy_keyframes(
    source_curve: bpy.types.FCurve,
    target_curve: bpy.types.FCurve,
    source_bone: str,
    root_source: str | None,
    root_motion: str,
    scale_ratio: float,
) -> None:
    is_location = source_curve.data_path.endswith(".location")
    for source_point in source_curve.keyframe_points:
        value = float(source_point.co[1])
        if is_location:
            mode = root_motion if source_bone == root_source else "keep"
            value = remap_location_value(value, source_curve.array_index, mode, scale_ratio)
        point = target_curve.keyframe_points.insert(float(source_point.co[0]), value, options={"FAST"})
        point.interpolation = source_point.interpolation
    target_curve.update()


def transfer_action(
    source: bpy.types.Object,
    target: bpy.types.Object,
    source_action: bpy.types.Action,
    action_name: str,
    explicit_map: dict[str, str],
    required_bones: list[str],
    root_target: str,
    root_motion: str,
    scale_ratio: float,
    max_rest_axis_angle_degrees: float,
    max_rest_basis_angle_degrees: float,
) -> dict[str, Any]:
    source_names = [bone.name for bone in source.data.bones]
    target_names = [bone.name for bone in target.data.bones]
    try:
        bone_map = build_bone_map(source_names, target_names, explicit_map)
    except MappingError as exc:
        raise HandoffError("BONE_MAP_INVALID", str(exc)) from exc
    missing = [name for name in required_bones if name not in bone_map.values()]
    if missing:
        raise HandoffError("REQUIRED_BONES_UNMAPPED", ", ".join(missing))
    rest_axis_angles: dict[str, float] = {}
    rest_basis_angles: dict[str, float] = {}
    for source_name, target_name in bone_map.items():
        source_axis = source.matrix_world.to_3x3() @ source.data.bones[source_name].vector
        target_axis = target.matrix_world.to_3x3() @ target.data.bones[target_name].vector
        try:
            angle = axis_angle_degrees(source_axis, target_axis)
        except MappingError as exc:
            raise HandoffError("REST_AXIS_INVALID", str(exc)) from exc
        rest_axis_angles[f"{source_name}->{target_name}"] = angle
        source_basis = (source.matrix_world.to_3x3() @ source.data.bones[source_name].matrix_local.to_3x3()).normalized()
        target_basis = (target.matrix_world.to_3x3() @ target.data.bones[target_name].matrix_local.to_3x3()).normalized()
        basis_angle = math.degrees(source_basis.to_quaternion().rotation_difference(target_basis.to_quaternion()).angle)
        rest_basis_angles[f"{source_name}->{target_name}"] = basis_angle
    worst_axis_angle = max(rest_axis_angles.values(), default=0.0)
    worst_basis_angle = max(rest_basis_angles.values(), default=0.0)
    if worst_axis_angle > max_rest_axis_angle_degrees:
        raise HandoffError(
            "REST_AXIS_MISMATCH",
            f"maximum rest-axis angle {worst_axis_angle:.3f} exceeds {max_rest_axis_angle_degrees:.3f} degrees",
        )
    if worst_basis_angle > max_rest_basis_angle_degrees:
        raise HandoffError(
            "REST_BASIS_MISMATCH",
            f"maximum rest-basis angle {worst_basis_angle:.3f} exceeds {max_rest_basis_angle_degrees:.3f} degrees",
        )
    root_sources = [name for name, mapped in bone_map.items() if mapped == root_target]
    root_source = root_sources[0] if len(root_sources) == 1 else None

    target_action = bpy.data.actions.get(action_name)
    if target_action:
        bpy.data.actions.remove(target_action)
    target_action = bpy.data.actions.new(action_name)
    target.animation_data_create()
    target.animation_data.action = target_action

    mapped_curves = 0
    skipped_curves = 0
    keyed_frames: set[float] = set()
    animated_target_bones: set[str] = set()
    for source_curve in action_fcurves(source_action):
        source_bone = source_bone_from_path(source_curve.data_path)
        if source_bone is None:
            skipped_curves += 1
            continue
        target_path = remap_data_path(source_curve.data_path, bone_map)
        if target_path is None:
            skipped_curves += 1
            continue
        target_bone = bone_map[source_bone]
        animated_target_bones.add(target_bone)
        keyed_frames.update(float(point.co[0]) for point in source_curve.keyframe_points)
        if source_bone in source.pose.bones and target_bone in target.pose.bones:
            target.pose.bones[target_bone].rotation_mode = source.pose.bones[source_bone].rotation_mode
        target_curve = target_action.fcurve_ensure_for_datablock(
            target,
            target_path,
            index=source_curve.array_index,
            group_name=target_bone,
        )
        copy_keyframes(
            source_curve,
            target_curve,
            source_bone,
            root_source,
            root_motion,
            scale_ratio,
        )
        mapped_curves += 1
    if mapped_curves == 0:
        raise HandoffError("ACTION_HAS_NO_MAPPED_CURVES", source_action.name)
    ordered_frames = sorted(keyed_frames)
    if len(ordered_frames) < 2:
        raise HandoffError("ACTION_STATIC", "action has fewer than two keyed frames")

    def set_scene_frame(value: float) -> None:
        whole = math.floor(value)
        bpy.context.scene.frame_set(whole, subframe=value - whole)
        bpy.context.view_layer.update()

    set_scene_frame(ordered_frames[0])
    baseline = {name: target.pose.bones[name].matrix.copy() for name in animated_target_bones}
    max_translation = 0.0
    max_rotation_degrees = 0.0
    for frame in ordered_frames[1:]:
        set_scene_frame(frame)
        for name in animated_target_bones:
            delta = baseline[name].inverted() @ target.pose.bones[name].matrix
            max_translation = max(max_translation, delta.to_translation().length)
            max_rotation_degrees = max(max_rotation_degrees, math.degrees(delta.to_quaternion().angle))
    set_scene_frame(ordered_frames[0])
    if max_translation <= 1e-5 and max_rotation_degrees <= 0.01:
        raise HandoffError("ACTION_STATIC", "mapped action does not change the target pose")
    target_action.use_fake_user = True
    return {
        "name": action_name,
        "source_action": source_action.name,
        "mapped_bone_count": len(bone_map),
        "mapped_curve_count": mapped_curves,
        "skipped_curve_count": skipped_curves,
        "frame_range": [float(source_action.frame_range[0]), float(source_action.frame_range[1])],
        "root_motion": root_motion,
        "scale_ratio": scale_ratio,
        "max_rest_axis_angle_degrees": worst_axis_angle,
        "rest_axis_angles": rest_axis_angles,
        "max_rest_basis_angle_degrees": worst_basis_angle,
        "rest_basis_angles": rest_basis_angles,
        "max_pose_translation": max_translation,
        "max_pose_rotation_degrees": max_rotation_degrees,
    }


def remove_imported(objects: list[bpy.types.Object]) -> None:
    for obj in objects:
        if obj.name in bpy.data.objects:
            bpy.data.objects.remove(obj, do_unlink=True)


def run(config_path: Path) -> dict[str, Any]:
    config = load_json(config_path)
    base = config_path.parent
    required_fields = ["base_character", "motions", "output_blend", "output_glb", "output_report"]
    missing_fields = [field for field in required_fields if field not in config]
    if missing_fields:
        raise HandoffError("CONFIG_INVALID", f"missing fields: {missing_fields}")
    motions = config["motions"]
    if not isinstance(motions, list) or not motions:
        raise HandoffError("MOTIONS_REQUIRED", "motions must be a non-empty array")

    character_path = resolve(base, str(config["base_character"]))
    output_blend = resolve(base, str(config["output_blend"]))
    output_glb = resolve(base, str(config["output_glb"]))
    output_report = resolve(base, str(config["output_report"]))
    open_character(character_path)
    target = find_armature(bpy.data.objects, config.get("target_armature"), "target")
    removed_existing_actions = clear_existing_target_animation(target)
    required_bones = [str(item) for item in config.get("required_bones", [])]
    root_target = str(config.get("root_bone", "Hips"))
    explicit_map = {str(k): str(v) for k, v in config.get("bone_map", {}).items()}
    default_scale = float(config.get("location_scale", 1.0))

    motion_reports = []
    input_hashes = {str(character_path): sha256_file(character_path)}
    for motion in motions:
        if not isinstance(motion, dict) or "path" not in motion or "name" not in motion:
            raise HandoffError("MOTION_CONFIG_INVALID", repr(motion))
        path = resolve(base, str(motion["path"]))
        input_hashes[str(path)] = sha256_file(path) if path.is_file() else "MISSING"
        before_actions = set(bpy.data.actions)
        imported = import_asset(path)
        source = find_armature(imported, motion.get("source_armature"), "source")
        new_actions = [action for action in bpy.data.actions if action not in before_actions]
        source_action = choose_source_action(source, new_actions)
        report = transfer_action(
            source,
            target,
            source_action,
            str(motion["name"]),
            explicit_map,
            required_bones,
            root_target,
            str(motion.get("root_motion", "keep")),
            float(motion.get("location_scale", default_scale)),
            float(motion.get("max_rest_axis_angle_degrees", config.get("max_rest_axis_angle_degrees", 15.0))),
            float(motion.get("max_rest_basis_angle_degrees", config.get("max_rest_basis_angle_degrees", 15.0))),
        )
        report["source"] = str(path)
        motion_reports.append(report)
        remove_imported(imported)
        for source_action in new_actions:
            if source_action.name in bpy.data.actions:
                bpy.data.actions.remove(source_action)

    output_blend.parent.mkdir(parents=True, exist_ok=True)
    output_glb.parent.mkdir(parents=True, exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=str(output_blend))
    bpy.ops.export_scene.gltf(
        filepath=str(output_glb),
        export_format="GLB",
        export_animations=True,
        export_animation_mode="ACTIONS",
        export_anim_single_armature=True,
    )
    if not output_glb.is_file() or output_glb.stat().st_size == 0:
        raise HandoffError("GLB_EXPORT_MISSING", str(output_glb))
    return {
        "status": "PASS",
        "code": "MIXAMO_HANDOFF_READY",
        "target_armature": target.name,
        "removed_existing_target_actions": removed_existing_actions,
        "input_sha256": input_hashes,
        "output_blend": str(output_blend),
        "output_glb": str(output_glb),
        "motions": motion_reports,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Mixamo FBX to Blender/Godot handoff")
    parser.add_argument("--config", required=True)
    args = parser.parse_args(sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else sys.argv[1:])
    config_path = Path(args.config).resolve()
    report_path = config_path.with_name("mixamo-handoff-report.json")
    try:
        config = load_json(config_path)
        if "output_report" in config:
            report_path = resolve(config_path.parent, str(config["output_report"]))
        payload = run(config_path)
        write_report(report_path, payload)
        print(json.dumps(payload, ensure_ascii=False))
        return 0
    except HandoffError as exc:
        payload = {"status": "FAIL", "code": exc.code, "message": str(exc)}
        write_report(report_path, payload)
        print(json.dumps(payload, ensure_ascii=False))
        return 2
    except Exception as exc:
        payload = {"status": "FAIL", "code": "UNEXPECTED_ERROR", "message": str(exc)}
        write_report(report_path, payload)
        print(json.dumps(payload, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
