#!/usr/bin/env python3
"""Verify a live Blender-MCP GUI connection and optionally start Blender."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Any


def write_report(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def receive_json(connection: socket.socket) -> dict[str, Any]:
    data = b""
    while True:
        chunk = connection.recv(8192)
        if not chunk:
            raise ConnectionError("Blender-MCP closed the socket before returning JSON")
        data += chunk
        try:
            value = json.loads(data.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            continue
        if not isinstance(value, dict):
            raise ValueError("Blender-MCP response root is not an object")
        return value


def send_command(host: str, port: int, command: str, timeout: float) -> Any:
    request = json.dumps({"type": command, "params": {}}).encode("utf-8")
    with socket.create_connection((host, port), timeout=timeout) as connection:
        connection.settimeout(timeout)
        connection.sendall(request)
        response = receive_json(connection)
    if response.get("status") != "success":
        raise RuntimeError(str(response.get("message", "Blender-MCP command failed")))
    return response.get("result")


def discover_blender(configured: str) -> str | None:
    if configured and configured != "auto":
        path = Path(os.path.expandvars(configured))
        return str(path) if path.is_file() else None
    found = shutil.which("blender")
    if found:
        return found
    if os.name == "nt":
        candidates = sorted(
            Path("C:/Program Files/Blender Foundation").glob("Blender */blender.exe"),
            reverse=True,
        )
        if candidates:
            return str(candidates[0])
    return None


def launch_blender(executable: str, extra_args: list[str]) -> subprocess.Popen[Any]:
    kwargs: dict[str, Any] = {
        "stdin": subprocess.DEVNULL,
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "close_fds": True,
    }
    if os.name == "nt":
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = subprocess.SW_HIDE
        kwargs["startupinfo"] = startupinfo
        kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
    return subprocess.Popen([executable, *extra_args], **kwargs)


def fail(output: Path, code: str, message: str, started: bool) -> int:
    payload = {
        "status": "FAIL",
        "code": code,
        "message": message,
        "started_process": started,
    }
    write_report(output, payload)
    print(json.dumps(payload, ensure_ascii=False))
    return 2


def main() -> int:
    parser = argparse.ArgumentParser(description="Blender-MCP live GUI health gate")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=9876)
    parser.add_argument("--timeout", type=float, default=15.0)
    parser.add_argument("--socket-timeout", type=float, default=2.0)
    parser.add_argument("--expected-protocol", type=int, default=5)
    parser.add_argument("--start-if-needed", action="store_true")
    parser.add_argument("--blender", default="auto")
    parser.add_argument("--blender-arg", action="append", default=[])
    parser.add_argument("--blend-file")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    output = Path(args.output).resolve()
    started = False
    deadline = time.monotonic() + max(args.timeout, 0.1)

    try:
        addon = send_command(args.host, args.port, "get_addon_info", args.socket_timeout)
    except Exception as initial_error:
        if not args.start_if_needed:
            return fail(output, "MCP_UNREACHABLE", str(initial_error), started)
        blender = discover_blender(args.blender)
        if not blender:
            return fail(output, "BLENDER_NOT_FOUND", "Blender executable was not found", started)
        launch_args = list(args.blender_arg)
        if args.blend_file:
            blend_file = Path(args.blend_file).resolve()
            if not blend_file.is_file():
                return fail(output, "BLEND_FILE_NOT_FOUND", str(blend_file), started)
            launch_args.insert(0, str(blend_file))
        try:
            launch_blender(blender, launch_args)
            started = True
        except OSError as exc:
            return fail(output, "BLENDER_START_FAILED", str(exc), started)

        last_error: Exception = initial_error
        addon = None
        while time.monotonic() < deadline:
            try:
                addon = send_command(args.host, args.port, "get_addon_info", args.socket_timeout)
                break
            except Exception as exc:
                last_error = exc
                time.sleep(0.1)
        if addon is None:
            return fail(output, "MCP_START_TIMEOUT", str(last_error), started)

    if not isinstance(addon, dict):
        return fail(output, "MCP_BAD_HANDSHAKE", "get_addon_info returned a non-object", started)
    actual_protocol = addon.get("protocol_version")
    if actual_protocol != args.expected_protocol:
        return fail(
            output,
            "MCP_PROTOCOL_MISMATCH",
            f"expected protocol {args.expected_protocol}, got {actual_protocol}",
            started,
        )
    capabilities = addon.get("capabilities", [])
    if not isinstance(capabilities, list) or "get_scene_info" not in capabilities:
        return fail(output, "MCP_CAPABILITY_MISSING", "get_scene_info is unavailable", started)
    try:
        scene = send_command(args.host, args.port, "get_scene_info", args.socket_timeout)
    except Exception as exc:
        return fail(output, "MCP_SCENE_QUERY_FAILED", str(exc), started)
    if not isinstance(scene, dict):
        return fail(output, "MCP_BAD_SCENE_RESPONSE", "get_scene_info returned a non-object", started)

    payload = {
        "status": "PASS",
        "code": "MCP_LIVE",
        "host": args.host,
        "port": args.port,
        "started_process": started,
        "addon": addon,
        "scene": scene,
    }
    write_report(output, payload)
    print(json.dumps(payload, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
