#!/usr/bin/env python3
"""Deterministic, resumable executor for the 3d-pipeline skill.

The executor never submits external/paid work by itself.  It runs only the
commands explicitly placed in a project contract and stops at missing approval,
an unconfigured gate, a non-zero exit, or a failing machine-readable report.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SCHEMA_VERSION = "1.4"
STATE_DIR = ".3d-pipeline"
STATE_FILE = "run-state.json"
DEFAULT_STAGE_IDS = (
    "preflight",
    "blender_mcp_gate",
    "asset_gate",
    "mixamo_handoff",
    "rig_gate",
    "export_gate",
    "godot_gate",
    "representative_frame",
    "final_render",
)


class ContractError(ValueError):
    pass


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ContractError(f"missing JSON file: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ContractError(f"invalid JSON in {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ContractError(f"JSON root must be an object: {path}")
    return value


def atomic_write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_json(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def resolve_path(config_dir: Path, raw: str) -> Path:
    expanded = os.path.expandvars(raw)
    path = Path(expanded)
    return path if path.is_absolute() else (config_dir / path).resolve()


def hash_paths(config_dir: Path, paths: list[str]) -> dict[str, str]:
    result: dict[str, str] = {}
    for raw in paths:
        path = resolve_path(config_dir, raw)
        key = str(path)
        result[key] = sha256_file(path) if path.is_file() else "MISSING"
    return result


def state_path_for(config_path: Path) -> Path:
    return config_path.parent / STATE_DIR / STATE_FILE


def validate_contract(config: dict[str, Any]) -> None:
    if config.get("schema_version") != SCHEMA_VERSION:
        raise ContractError(f"schema_version must be {SCHEMA_VERSION}")
    project = config.get("project")
    if not isinstance(project, dict):
        raise ContractError("project must be an object")
    duration = project.get("duration_seconds")
    if not isinstance(duration, (int, float)) or not 1 <= duration <= 30:
        raise ContractError("project.duration_seconds must be between 1 and 30")
    fps = project.get("fps")
    if not isinstance(fps, int) or fps <= 0:
        raise ContractError("project.fps must be a positive integer")
    resolution = project.get("resolution")
    if not isinstance(resolution, list) or len(resolution) != 2 or not all(isinstance(item, int) and item > 0 for item in resolution):
        raise ContractError("project.resolution must contain two positive integers")
    quality = project.get("quality")
    if quality not in {"Q0", "Q1", "Q2"}:
        raise ContractError("project.quality must be Q0, Q1, or Q2")
    stages = config.get("stages")
    if not isinstance(stages, list) or not stages:
        raise ContractError("stages must be a non-empty array")
    ids: list[str] = []
    for stage in stages:
        if not isinstance(stage, dict) or not isinstance(stage.get("id"), str) or not stage["id"]:
            raise ContractError("every stage requires a non-empty id")
        if stage.get("type") not in {"preflight", "command"}:
            raise ContractError(f"unsupported stage type for {stage['id']}")
        if stage.get("type") == "command" and stage.get("configured", True):
            command = stage.get("command")
            if not isinstance(command, list) or not command or not all(isinstance(item, str) for item in command):
                raise ContractError(f"stage {stage['id']} requires a command array")
        ids.append(stage["id"])
    if len(ids) != len(set(ids)):
        raise ContractError("stage ids must be unique")


def new_state(config: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "pipeline_status": "pending",
        "config_sha256": sha256_json(config),
        "created_at": utc_now(),
        "updated_at": utc_now(),
        "approvals": {},
        "tools": {},
        "stages": {
            stage["id"]: {"status": "pending", "attempts": 0}
            for stage in config["stages"]
        },
    }


def load_state(config_path: Path, config: dict[str, Any]) -> dict[str, Any]:
    path = state_path_for(config_path)
    if not path.exists():
        state = new_state(config)
        atomic_write_json(path, state)
        return state
    state = read_json(path)
    current_hash = sha256_json(config)
    if state.get("config_sha256") != current_hash:
        state["config_sha256"] = current_hash
        state["approvals"] = {}
        state["pipeline_status"] = "pending"
        old_stages = state.get("stages", {})
        state["stages"] = {
            stage["id"]: old_stages.get(stage["id"], {"status": "pending", "attempts": 0})
            for stage in config["stages"]
        }
        for item in state["stages"].values():
            item["status"] = "pending"
            item.pop("report", None)
        state["updated_at"] = utc_now()
        atomic_write_json(path, state)
        print("CONFIG_CHANGED_APPROVALS_CLEARED")
    return state


def default_contract(args: argparse.Namespace) -> dict[str, Any]:
    width, height = (int(part) for part in args.resolution.lower().split("x", 1))
    mcp_gate = str(Path(__file__).resolve().with_name("blender_mcp_gate.py"))
    project = {
        "name": args.name,
        "quality": args.quality,
        "duration_seconds": args.duration,
        "fps": args.fps,
        "frame_count": round(args.duration * args.fps),
        "resolution": [width, height],
        "preview_only": True,
    }
    return {
        "schema_version": SCHEMA_VERSION,
        "project": project,
        "tools": {
            "blender": {"path": "auto", "version_args": ["--version"]},
            "godot": {"path": "auto", "version_args": ["--version"]},
            "ffmpeg": {"path": "auto", "version_args": ["-version"]},
            "ffprobe": {"path": "auto", "version_args": ["-version"]},
        },
        "stages": [
            {"id": "preflight", "type": "preflight"},
            {
                "id": "blender_mcp_gate",
                "type": "command",
                "configured": True,
                "always_run": True,
                "outputs": ["reports/blender-mcp-gate.json"],
                "command": [
                    sys.executable,
                    mcp_gate,
                    "--start-if-needed",
                    "--blender",
                    "auto",
                    "--output",
                    "{config_dir}/reports/blender-mcp-gate.json",
                ],
                "report": {
                    "path": "reports/blender-mcp-gate.json",
                    "status_field": "status",
                    "pass_values": ["PASS"],
                },
                "timeout_seconds": 45,
            },
            {"id": "asset_gate", "type": "command", "configured": False, "command": []},
            {"id": "mixamo_handoff", "type": "command", "configured": False, "command": []},
            {"id": "rig_gate", "type": "command", "configured": False, "command": []},
            {"id": "export_gate", "type": "command", "configured": False, "command": []},
            {"id": "godot_gate", "type": "command", "configured": False, "command": []},
            {"id": "representative_frame", "type": "command", "configured": False, "command": []},
            {
                "id": "final_render",
                "type": "command",
                "configured": False,
                "command": [],
                "requires_approvals": ["representative_frame_accepted"],
            },
        ],
    }


def discover_tool(name: str, configured_path: str) -> str | None:
    if configured_path and configured_path != "auto":
        path = Path(os.path.expandvars(configured_path))
        return str(path) if path.is_file() else None
    found = shutil.which(name)
    if found:
        return found
    candidates: list[Path] = []
    if os.name == "nt":
        if name == "blender":
            candidates.extend(sorted(Path("C:/Program Files/Blender Foundation").glob("Blender */blender.exe"), reverse=True))
        elif name == "godot":
            candidates.extend(sorted(Path.home().glob("AppData/Local/Microsoft/WinGet/Packages/GodotEngine.GodotEngine_*/Godot_*_console.exe"), reverse=True))
            candidates.extend(sorted((Path.home() / "Documents" / "Codex" / "Tools" / "Godot").glob("*/Godot_*_console.exe"), reverse=True))
    return str(candidates[0]) if candidates else None


def run_preflight(config: dict[str, Any], state: dict[str, Any]) -> tuple[int, str, str, dict[str, Any]]:
    tool_results: dict[str, Any] = {}
    failures: list[str] = []
    for name, settings in config.get("tools", {}).items():
        if not isinstance(settings, dict):
            failures.append(f"invalid tool settings: {name}")
            continue
        resolved = discover_tool(name, str(settings.get("path", "auto")))
        if not resolved:
            tool_results[name] = {"available": False}
            failures.append(f"tool not found: {name}")
            continue
        version_args = settings.get("version_args", ["--version"])
        try:
            completed = subprocess.run(
                [resolved, *version_args],
                text=True,
                capture_output=True,
                encoding="utf-8",
                errors="replace",
                timeout=20,
            )
            version_text = (completed.stdout or completed.stderr).strip().splitlines()
            tool_results[name] = {
                "available": completed.returncode == 0,
                "path": resolved,
                "version": version_text[0] if version_text else "",
            }
            if completed.returncode != 0:
                failures.append(f"version probe failed: {name}")
        except (OSError, subprocess.TimeoutExpired) as exc:
            tool_results[name] = {"available": False, "path": resolved, "error": str(exc)}
            failures.append(f"tool probe failed: {name}")
    state["tools"] = tool_results
    report = {"status": "FAIL" if failures else "PASS", "failures": failures, "tools": tool_results}
    return (2 if failures else 0, json.dumps(report, ensure_ascii=False), "", report)


def nested_value(value: dict[str, Any], path: str) -> Any:
    current: Any = value
    for part in path.split("."):
        if not isinstance(current, dict) or part not in current:
            raise ContractError(f"report field not found: {path}")
        current = current[part]
    return current


def expanded_command(stage: dict[str, Any], config_path: Path) -> list[str]:
    replacements = {
        "{config_dir}": str(config_path.parent),
        "{config}": str(config_path),
    }
    result = []
    for raw in stage["command"]:
        value = os.path.expandvars(raw)
        for key, replacement in replacements.items():
            value = value.replace(key, replacement)
        result.append(value)
    return result


def run_command_stage(stage: dict[str, Any], config_path: Path) -> tuple[int, str, str, dict[str, Any] | None]:
    command = expanded_command(stage, config_path)
    timeout = int(stage.get("timeout_seconds", 1800))
    try:
        completed = subprocess.run(
            command,
            cwd=config_path.parent,
            text=True,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            shell=False,
        )
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout if isinstance(exc.stdout, str) else ""
        stderr = exc.stderr if isinstance(exc.stderr, str) else ""
        return 5, stdout, stderr + f"\nTIMEOUT after {timeout}s", None
    except OSError as exc:
        return 2, "", str(exc), None

    report_value: dict[str, Any] | None = None
    if stage.get("report"):
        report_config = stage["report"]
        try:
            report_path = resolve_path(config_path.parent, report_config["path"])
            report_value = read_json(report_path)
            actual = nested_value(report_value, report_config.get("status_field", "status"))
            pass_values = report_config.get("pass_values", ["PASS"])
            if completed.returncode == 0 and actual not in pass_values:
                return 4, completed.stdout, completed.stderr, report_value
        except (KeyError, ContractError) as exc:
            if completed.returncode == 0:
                return 4, completed.stdout, completed.stderr + f"\nREPORT_ERROR: {exc}", report_value
            completed.stderr += f"\nREPORT_ERROR: {exc}"
    return completed.returncode, completed.stdout, completed.stderr, report_value


def truncate_log(value: str, maximum: int = 20000) -> str:
    return value if len(value) <= maximum else value[-maximum:]


def invalidate_from(state: dict[str, Any], stages: list[dict[str, Any]], start: int) -> None:
    for stage in stages[start:]:
        item = state["stages"].setdefault(stage["id"], {"attempts": 0})
        item["status"] = "pending"
        item.pop("report", None)


def command_run(args: argparse.Namespace) -> int:
    config_path = Path(args.config).resolve()
    try:
        config = read_json(config_path)
        validate_contract(config)
    except ContractError as exc:
        print(f"CONTRACT_INVALID: {exc}", file=sys.stderr)
        return 2
    state = load_state(config_path, config)
    state_path = state_path_for(config_path)
    stages = config["stages"]
    stage_ids = [stage["id"] for stage in stages]
    if args.through and args.through not in stage_ids:
        print(f"UNKNOWN_STAGE={args.through}", file=sys.stderr)
        return 2

    for index, stage in enumerate(stages):
        stage_id = stage["id"]
        item = state["stages"].setdefault(stage_id, {"status": "pending", "attempts": 0})
        current_inputs = hash_paths(config_path.parent, stage.get("inputs", []))
        current_outputs = hash_paths(config_path.parent, stage.get("outputs", []))
        cached = (
            stage["type"] != "preflight"
            and not stage.get("always_run", False)
            and item.get("status") == "passed"
            and item.get("input_sha256", {}) == current_inputs
        )
        if cached and all(value != "MISSING" for value in current_outputs.values()) and item.get("output_sha256", {}) == current_outputs:
            print(f"STAGE_SKIPPED={stage_id}")
            if args.through == stage_id:
                break
            continue
        if item.get("status") == "passed":
            print(f"CACHE_INVALIDATED={stage_id}")
            invalidate_from(state, stages, index)

        missing_approvals = [
            gate for gate in stage.get("requires_approvals", [])
            if gate not in state.get("approvals", {})
        ]
        if missing_approvals:
            item.update({"status": "blocked", "reason": "APPROVAL_REQUIRED", "missing_approvals": missing_approvals})
            state["pipeline_status"] = "blocked"
            state["updated_at"] = utc_now()
            atomic_write_json(state_path, state)
            print(f"APPROVAL_REQUIRED={','.join(missing_approvals)}")
            return 3
        if not stage.get("configured", True):
            item.update({"status": "blocked", "reason": "STAGE_NOT_CONFIGURED"})
            state["pipeline_status"] = "blocked"
            state["updated_at"] = utc_now()
            atomic_write_json(state_path, state)
            print(f"STAGE_NOT_CONFIGURED={stage_id}")
            return 6

        item["status"] = "running"
        item["attempts"] = int(item.get("attempts", 0)) + 1
        item["started_at"] = utc_now()
        item["input_sha256"] = current_inputs
        atomic_write_json(state_path, state)
        started = time.monotonic()
        if stage["type"] == "preflight":
            code, stdout, stderr, report = run_preflight(config, state)
        else:
            code, stdout, stderr, report = run_command_stage(stage, config_path)
        item["duration_seconds"] = round(time.monotonic() - started, 3)
        item["stdout"] = truncate_log(stdout)
        item["stderr"] = truncate_log(stderr)
        item["exit_code"] = code
        item["finished_at"] = utc_now()
        if report is not None:
            item["report"] = report
        if code != 0:
            item["status"] = "failed"
            state["pipeline_status"] = "failed"
            state["updated_at"] = utc_now()
            atomic_write_json(state_path, state)
            if stdout:
                print(stdout, end="" if stdout.endswith("\n") else "\n")
            if stderr:
                print(stderr, file=sys.stderr)
            print(f"STAGE_FAILED={stage_id}", file=sys.stderr)
            return code if 0 < code <= 255 else 1

        item["status"] = "passed"
        item["output_sha256"] = hash_paths(config_path.parent, stage.get("outputs", []))
        state["pipeline_status"] = "running"
        state["updated_at"] = utc_now()
        atomic_write_json(state_path, state)
        print(f"STAGE_PASSED={stage_id}")
        if args.through == stage_id:
            break

    if all(item.get("status") == "passed" for item in state["stages"].values()):
        state["pipeline_status"] = "complete"
    elif state["pipeline_status"] not in {"failed", "blocked"}:
        state["pipeline_status"] = "pending"
    state["updated_at"] = utc_now()
    atomic_write_json(state_path, state)
    print(f"PIPELINE_STATUS={state['pipeline_status']}")
    return 0


def command_init(args: argparse.Namespace) -> int:
    workspace = Path(args.workspace).resolve()
    workspace.mkdir(parents=True, exist_ok=True)
    config_path = workspace / "3d-pipeline.json"
    if config_path.exists() and not args.force:
        print(f"CONFIG_EXISTS: {config_path}", file=sys.stderr)
        return 2
    try:
        config = default_contract(args)
        validate_contract(config)
    except (ContractError, ValueError) as exc:
        print(f"CONTRACT_INVALID: {exc}", file=sys.stderr)
        return 2
    atomic_write_json(config_path, config)
    atomic_write_json(state_path_for(config_path), new_state(config))
    print(f"CONFIG_CREATED={config_path}")
    print(f"STATE_CREATED={state_path_for(config_path)}")
    return 0


def command_approve(args: argparse.Namespace) -> int:
    config_path = Path(args.config).resolve()
    try:
        config = read_json(config_path)
        validate_contract(config)
    except ContractError as exc:
        print(f"CONTRACT_INVALID: {exc}", file=sys.stderr)
        return 2
    state = load_state(config_path, config)
    allowed = {
        gate
        for stage in config["stages"]
        for gate in stage.get("requires_approvals", [])
    }
    if args.gate not in allowed:
        print(f"UNKNOWN_APPROVAL_GATE={args.gate}", file=sys.stderr)
        return 2
    state.setdefault("approvals", {})[args.gate] = {
        "actor": args.actor,
        "note": args.note,
        "approved_at": utc_now(),
        "config_sha256": sha256_json(config),
    }
    for item in state["stages"].values():
        if item.get("status") == "blocked" and item.get("reason") == "APPROVAL_REQUIRED":
            item["status"] = "pending"
    state["pipeline_status"] = "pending"
    state["updated_at"] = utc_now()
    atomic_write_json(state_path_for(config_path), state)
    print(f"APPROVAL_RECORDED={args.gate}")
    return 0


def command_status(args: argparse.Namespace) -> int:
    config_path = Path(args.config).resolve()
    try:
        config = read_json(config_path)
        validate_contract(config)
        state = load_state(config_path, config)
    except ContractError as exc:
        print(f"CONTRACT_INVALID: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(state, ensure_ascii=False, indent=2))
    return 0


def command_configure_mixamo(args: argparse.Namespace) -> int:
    config_path = Path(args.config).resolve()
    mixamo_path = Path(args.mixamo_config).resolve()
    try:
        config = read_json(config_path)
        validate_contract(config)
        mixamo = read_json(mixamo_path)
        required = ["base_character", "motions", "output_blend", "output_glb", "output_report"]
        missing = [field for field in required if field not in mixamo]
        if missing:
            raise ContractError(f"Mixamo config missing fields: {missing}")
        motions = mixamo["motions"]
        if not isinstance(motions, list) or not motions:
            raise ContractError("Mixamo motions must be a non-empty array")
        mixamo_dir = mixamo_path.parent
        base_character = resolve_path(mixamo_dir, str(mixamo["base_character"]))
        motion_paths: list[Path] = []
        for motion in motions:
            if not isinstance(motion, dict) or "path" not in motion or "name" not in motion:
                raise ContractError(f"invalid Mixamo motion entry: {motion!r}")
            motion_paths.append(resolve_path(mixamo_dir, str(motion["path"])))
        missing_inputs = [str(path) for path in [base_character, *motion_paths] if not path.is_file()]
        if missing_inputs:
            raise ContractError(f"Mixamo input files missing: {missing_inputs}")
        outputs = [
            resolve_path(mixamo_dir, str(mixamo["output_blend"])),
            resolve_path(mixamo_dir, str(mixamo["output_glb"])),
            resolve_path(mixamo_dir, str(mixamo["output_report"])),
        ]
        blender_settings = config.get("tools", {}).get("blender", {})
        blender = discover_tool("blender", str(blender_settings.get("path", "auto")))
        if not blender:
            raise ContractError("Blender executable was not found")
    except ContractError as exc:
        print(f"MIXAMO_CONFIG_INVALID: {exc}", file=sys.stderr)
        return 2

    handoff_script = str(Path(__file__).resolve().with_name("blender_mixamo_handoff.py"))
    stage = {
        "id": "mixamo_handoff",
        "type": "command",
        "configured": True,
        "inputs": [str(mixamo_path), str(base_character), *[str(path) for path in motion_paths]],
        "outputs": [str(path) for path in outputs],
        "command": [
            blender,
            "--background",
            "--factory-startup",
            "--python",
            handoff_script,
            "--",
            "--config",
            str(mixamo_path),
        ],
        "report": {
            "path": str(outputs[2]),
            "status_field": "status",
            "pass_values": ["PASS"],
        },
        "timeout_seconds": 1800,
    }
    stages = config["stages"]
    existing = next((index for index, item in enumerate(stages) if item["id"] == "mixamo_handoff"), None)
    if existing is not None:
        stages[existing] = stage
    else:
        rig_index = next((index for index, item in enumerate(stages) if item["id"] == "rig_gate"), len(stages))
        stages.insert(rig_index, stage)
    try:
        validate_contract(config)
    except ContractError as exc:
        print(f"CONTRACT_INVALID: {exc}", file=sys.stderr)
        return 2
    atomic_write_json(config_path, config)
    print(f"MIXAMO_STAGE_CONFIGURED={config_path}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="3D流水线 V1.5 本地执行器")
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init", help="创建项目合同和运行状态")
    init.add_argument("--workspace", required=True)
    init.add_argument("--name", required=True)
    init.add_argument("--quality", choices=("Q0", "Q1", "Q2"), default="Q1")
    init.add_argument("--duration", type=float, required=True)
    init.add_argument("--fps", type=int, default=30)
    init.add_argument("--resolution", default="1080x1920")
    init.add_argument("--force", action="store_true")
    init.set_defaults(func=command_init)

    run = sub.add_parser("run", help="从断点执行，失败立即停止")
    run.add_argument("--config", required=True)
    run.add_argument("--through")
    run.set_defaults(func=command_run)

    approve = sub.add_parser("approve", help="记录用户明确给出的单个审批门")
    approve.add_argument("--config", required=True)
    approve.add_argument("--gate", required=True)
    approve.add_argument("--actor", required=True)
    approve.add_argument("--note", required=True)
    approve.set_defaults(func=command_approve)

    status = sub.add_parser("status", help="输出当前机器可读状态")
    status.add_argument("--config", required=True)
    status.set_defaults(func=command_status)

    mixamo = sub.add_parser("configure-mixamo", help="把本地 Mixamo FBX 自动交接阶段写入合同")
    mixamo.add_argument("--config", required=True)
    mixamo.add_argument("--mixamo-config", required=True)
    mixamo.set_defaults(func=command_configure_mixamo)
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
