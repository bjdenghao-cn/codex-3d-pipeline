"""Blender-side deformation and physical grip gate for .blend/.glb/.fbx assets."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import bpy


sys.path.insert(0, str(Path(__file__).resolve().parent))
from gate_math import coerce_frame, evaluate_grip_side, max_edge_stretch


def cli_args() -> argparse.Namespace:
    raw = sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else []
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--output", required=True)
    return parser.parse_args(raw)


def load_input(path: Path) -> None:
    if path.suffix.lower() == ".blend":
        bpy.ops.wm.open_mainfile(filepath=str(path))
    else:
        bpy.ops.wm.read_factory_settings(use_empty=True)
        if path.suffix.lower() in {".glb", ".gltf"}:
            bpy.ops.import_scene.gltf(filepath=str(path))
        elif path.suffix.lower() == ".fbx":
            bpy.ops.import_scene.fbx(filepath=str(path))
        else:
            raise ValueError(f"unsupported rig format: {path.suffix}")


def evaluated_coordinates(obj, frame: int) -> list[tuple[float, float, float]]:
    bpy.context.scene.frame_set(frame)
    bpy.context.view_layer.update()
    depsgraph = bpy.context.evaluated_depsgraph_get()
    evaluated = obj.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh()
    try:
        return [tuple(evaluated.matrix_world @ vertex.co) for vertex in mesh.vertices]
    finally:
        evaluated.to_mesh_clear()


def group_members(obj, group_names: list[str], minimum: float) -> set[int]:
    indices = set()
    groups = [obj.vertex_groups.get(name) for name in group_names]
    groups = [group for group in groups if group is not None]
    group_ids = {group.index for group in groups}
    for vertex in obj.data.vertices:
        if any(item.group in group_ids and item.weight >= minimum for item in vertex.groups):
            indices.add(vertex.index)
    return indices


def main() -> int:
    args = cli_args()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    failures: list[dict[str, object]] = []
    report: dict[str, object] = {"status": "FAIL", "gate": "rig_gate", "failure_codes": failures}
    try:
        input_path = Path(args.input).resolve()
        config = json.loads(Path(args.config).read_text(encoding="utf-8"))
        load_input(input_path)
        body = bpy.data.objects.get(config["mesh_name"])
        rig = bpy.data.objects.get(config["armature_name"])
        if body is None or body.type != "MESH":
            failures.append({"code": "VISIBLE_MESH_MISSING", "name": config["mesh_name"]})
            raise RuntimeError("visible mesh missing")
        if rig is None or rig.type != "ARMATURE":
            failures.append({"code": "ARMATURE_MISSING", "name": config["armature_name"]})
            raise RuntimeError("armature missing")
        if body.hide_render or body.hide_viewport:
            failures.append({"code": "FORMAL_MESH_HIDDEN"})
        armature_modifiers = [modifier for modifier in body.modifiers if modifier.type == "ARMATURE" and modifier.object == rig]
        if not armature_modifiers:
            failures.append({"code": "ARMATURE_MODIFIER_MISSING"})

        required_bones = config.get("required_bones", [])
        missing_bones = [name for name in required_bones if rig.data.bones.get(name) is None]
        if missing_bones:
            failures.append({"code": "BONES_MISSING", "names": missing_bones})
        minimum_weight = float(config.get("minimum_weight", 0.05))
        minimum_vertices = int(config.get("minimum_vertices_per_group", 1))
        group_counts = {}
        for name in config.get("required_vertex_groups", required_bones):
            count = len(group_members(body, [name], minimum_weight))
            group_counts[name] = count
            if count < minimum_vertices:
                failures.append({"code": "VERTEX_GROUP_UNDERWEIGHTED", "name": name, "actual": count, "limit": minimum_vertices})

        action_name = config.get("action_name")
        action = bpy.data.actions.get(action_name) if action_name else None
        if action_name and action is None:
            failures.append({"code": "ACTION_MISSING", "name": action_name})
        elif action is not None:
            rig.animation_data_create()
            try:
                rig.animation_data.action = action
            except Exception as exc:
                failures.append({"code": "ACTION_ASSIGNMENT_FAILED", "message": str(exc)})

        rest_frame = coerce_frame(config.get("rest_frame", 1))
        pose_frame = coerce_frame(config.get("pose_frame", 30))
        rest = evaluated_coordinates(body, rest_frame)
        posed = evaluated_coordinates(body, pose_frame)
        max_displacement = max(
            ((sum((posed[index][axis] - rest[index][axis]) ** 2 for axis in range(3))) ** 0.5 for index in range(len(rest))),
            default=0.0,
        )
        if max_displacement < float(config.get("minimum_pose_displacement_m", 0.001)):
            failures.append({"code": "VISIBLE_MESH_NOT_DEFORMING", "actual": max_displacement})

        grip_reports = {}
        hand_members_all: set[int] = set()
        grip = config.get("grip")
        if grip:
            for side, side_config in grip.get("sides", {}).items():
                hand_names = side_config["hand_groups"]
                hand_members = group_members(body, hand_names, float(side_config.get("hand_minimum_weight", 0.2)))
                hand_members_all.update(hand_members)
                digit_members = {
                    digit: group_members(body, names, float(side_config.get("digit_minimum_weight", 0.12)))
                    for digit, names in side_config["digits"].items()
                }
                if not hand_members:
                    failures.append({"code": "HAND_GROUP_EMPTY", "side": side})
                    continue
                try:
                    result = evaluate_grip_side(
                        hand_points=[posed[index] for index in hand_members],
                        digit_points={digit: [posed[index] for index in members] for digit, members in digit_members.items()},
                        centre=side_config["centre"],
                        axis=side_config.get("axis", [0, 0, 1]),
                        half_length=float(side_config.get("half_length_m", grip.get("half_length_m", 0.085))),
                        radius=float(side_config.get("radius_m", grip.get("radius_m", 0.026))),
                        contact_tolerance=float(grip.get("contact_tolerance_m", 0.014)),
                        max_palm_penetration=float(grip.get("max_palm_penetration_m", 0.008)),
                        max_hand_target_distance=float(grip.get("max_hand_target_distance_m", 0.12)),
                        max_thumb_opposition_dot=float(grip.get("max_thumb_opposition_dot", -0.10)),
                    )
                except ValueError as exc:
                    result = {"status": "FAIL", "failure_codes": ["GRIP_GEOMETRY_INVALID"], "message": str(exc)}
                grip_reports[side] = result
                for code in result.get("failure_codes", []):
                    failures.append({"code": code, "side": side})

        if not hand_members_all:
            hand_members_all = set(range(len(body.data.vertices)))
        hand_edges = [
            tuple(edge.vertices)
            for edge in body.data.edges
            if edge.vertices[0] in hand_members_all and edge.vertices[1] in hand_members_all
        ]
        stretch = max_edge_stretch(rest, posed, hand_edges)
        max_ratio = float(config.get("max_edge_stretch_ratio", 2.2))
        max_extension = float(config.get("max_edge_extension_m", 0.004))
        if stretch["max_ratio"] > max_ratio and stretch["absolute_extension_m"] > max_extension:
            failures.append({"code": "SURFACE_TEAR", "actual_ratio": stretch["max_ratio"], "edge": stretch["edge"]})

        report.update(
            {
                "input": str(input_path),
                "mesh": body.name,
                "armature": rig.name,
                "bones": len(rig.data.bones),
                "vertex_groups": group_counts,
                "action": action_name,
                "rest_frame": rest_frame,
                "pose_frame": pose_frame,
                "max_pose_displacement_m": max_displacement,
                "stretch": stretch,
                "grip": grip_reports,
            }
        )
    except Exception as exc:
        if not failures:
            failures.append({"code": "RIG_GATE_EXCEPTION", "message": str(exc)})

    report["status"] = "FAIL" if failures else "PASS"
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
