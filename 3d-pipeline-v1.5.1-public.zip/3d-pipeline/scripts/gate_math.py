"""Dependency-free geometry checks shared by Blender gate scripts and tests."""

from __future__ import annotations

import math
from collections.abc import Iterable, Sequence
from typing import Any


Point = Sequence[float]


def coerce_frame(value: float | int) -> int:
    numeric = float(value)
    if not numeric.is_integer():
        raise ValueError(f"Blender gate frames must be a whole frame, got {value}")
    return int(numeric)


def _sub(a: Point, b: Point) -> tuple[float, float, float]:
    return (float(a[0] - b[0]), float(a[1] - b[1]), float(a[2] - b[2]))


def _add(a: Point, b: Point) -> tuple[float, float, float]:
    return (float(a[0] + b[0]), float(a[1] + b[1]), float(a[2] + b[2]))


def _scale(a: Point, scalar: float) -> tuple[float, float, float]:
    return (float(a[0] * scalar), float(a[1] * scalar), float(a[2] * scalar))


def _dot(a: Point, b: Point) -> float:
    return float(a[0] * b[0] + a[1] * b[1] + a[2] * b[2])


def _length(a: Point) -> float:
    return math.sqrt(_dot(a, a))


def _normalized(a: Point) -> tuple[float, float, float]:
    length = _length(a)
    if length <= 1e-12:
        raise ValueError("zero-length vector")
    return _scale(a, 1.0 / length)


def connected_components(selected: set[int], edges: Iterable[Sequence[int]]) -> list[int]:
    adjacency = {index: [] for index in selected}
    for edge in edges:
        a, b = int(edge[0]), int(edge[1])
        if a in selected and b in selected:
            adjacency[a].append(b)
            adjacency[b].append(a)
    sizes: list[int] = []
    remaining = set(selected)
    while remaining:
        root = remaining.pop()
        stack = [root]
        size = 0
        while stack:
            current = stack.pop()
            size += 1
            for neighbor in adjacency[current]:
                if neighbor in remaining:
                    remaining.remove(neighbor)
                    stack.append(neighbor)
        sizes.append(size)
    return sorted(sizes, reverse=True)


def point_segment_radial(point: Point, start: Point, end: Point) -> tuple[float, float, tuple[float, float, float]]:
    axis = _sub(end, start)
    length_squared = _dot(axis, axis)
    if length_squared <= 1e-12:
        raise ValueError("zero-length segment")
    relative = _sub(point, start)
    t = max(0.0, min(1.0, _dot(relative, axis) / length_squared))
    closest = _add(start, _scale(axis, t))
    offset = _sub(point, closest)
    return _length(offset), t, offset


def nearest_surface_contact(points: Sequence[Point], start: Point, end: Point, radius: float) -> dict[str, Any]:
    candidates = []
    for index, point in enumerate(points):
        radial, axial_t, offset = point_segment_radial(point, start, end)
        if 0.0 <= axial_t <= 1.0:
            candidates.append((abs(radial - radius), radial, index, offset))
    if not candidates:
        raise ValueError("no points project onto grip span")
    error, radial, index, offset = min(candidates, key=lambda item: item[0])
    return {"surface_error": error, "radial": radial, "index": index, "offset": offset}


def evaluate_grip_side(
    *,
    hand_points: Sequence[Point],
    digit_points: dict[str, Sequence[Point]],
    centre: Point,
    axis: Point,
    half_length: float,
    radius: float,
    contact_tolerance: float,
    max_palm_penetration: float,
    max_hand_target_distance: float,
    max_thumb_opposition_dot: float,
) -> dict[str, Any]:
    failures: list[str] = []
    unit_axis = _normalized(axis)
    start = _sub(centre, _scale(unit_axis, half_length))
    end = _add(centre, _scale(unit_axis, half_length))
    if not hand_points:
        raise ValueError("hand_points must not be empty")
    centroid = tuple(sum(point[axis_index] for point in hand_points) / len(hand_points) for axis_index in range(3))
    target_distance = _length(_sub(centroid, centre))
    if target_distance > max_hand_target_distance:
        failures.append("HAND_MISSES_TARGET")

    contact_errors: dict[str, float] = {}
    offsets: dict[str, tuple[float, float, float]] = {}
    for digit in ("thumb", "index", "middle", "ring", "pinky"):
        points = digit_points.get(digit, [])
        if not points:
            failures.append(f"MISSING_DIGIT_POINTS:{digit}")
            continue
        sample = nearest_surface_contact(points, start, end, radius)
        contact_errors[digit] = float(sample["surface_error"])
        offsets[digit] = sample["offset"]
        if sample["surface_error"] > contact_tolerance:
            failures.append(f"FINGER_MISSES_GRIP:{digit}")

    opposition = None
    if all(digit in offsets for digit in ("thumb", "index", "middle", "ring", "pinky")):
        thumb = _normalized(offsets["thumb"])
        opposing_sum = (0.0, 0.0, 0.0)
        for digit in ("index", "middle", "ring", "pinky"):
            opposing_sum = _add(opposing_sum, _normalized(offsets[digit]))
        opposition = _dot(thumb, _normalized(opposing_sum))
        if opposition > max_thumb_opposition_dot:
            failures.append("THUMB_NOT_OPPOSING")

    penetration = 0.0
    for point in hand_points:
        radial, axial_t, _offset = point_segment_radial(point, start, end)
        if 0.0 <= axial_t <= 1.0:
            penetration = max(penetration, radius - radial)
    if penetration > max_palm_penetration:
        failures.append("PALM_PENETRATION")

    return {
        "status": "FAIL" if failures else "PASS",
        "failure_codes": failures,
        "hand_target_distance_m": target_distance,
        "digit_contact_surface_errors_m": contact_errors,
        "thumb_opposition_dot": opposition,
        "max_palm_penetration_m": penetration,
    }


def max_edge_stretch(rest: Sequence[Point], posed: Sequence[Point], edges: Iterable[Sequence[int]]) -> dict[str, Any]:
    maximum = 1.0
    maximum_edge: list[int] | None = None
    maximum_extension = 0.0
    for edge in edges:
        a, b = int(edge[0]), int(edge[1])
        rest_length = _length(_sub(rest[a], rest[b]))
        if rest_length <= 1e-9:
            continue
        posed_length = _length(_sub(posed[a], posed[b]))
        ratio = posed_length / rest_length
        if ratio > maximum:
            maximum = ratio
            maximum_edge = [a, b]
            maximum_extension = posed_length - rest_length
    return {"max_ratio": maximum, "edge": maximum_edge, "absolute_extension_m": maximum_extension}
