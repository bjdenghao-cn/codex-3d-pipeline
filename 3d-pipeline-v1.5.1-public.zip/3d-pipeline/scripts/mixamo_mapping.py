"""Pure helpers for deterministic Mixamo-to-target action channel mapping."""

from __future__ import annotations

import re
import math
from collections.abc import Iterable, Mapping


class MappingError(ValueError):
    pass


_BONE_PATH = re.compile(r'pose\.bones\[(["\'])(.+?)\1\]')


def unprefixed(name: str) -> str:
    return name.rsplit(":", 1)[-1]


def canonical_bone_name(name: str) -> str:
    return re.sub(r"[^a-z0-9]", "", unprefixed(name).lower())


def bone_side(name: str) -> str | None:
    value = unprefixed(name).lower()
    compact = canonical_bone_name(name)
    if "left" in compact or value.endswith((".l", "_l", "-l")):
        return "L"
    if "right" in compact or value.endswith((".r", "_r", "-r")):
        return "R"
    return None


def _validate_pair(source: str, target: str) -> None:
    source_side = bone_side(source)
    target_side = bone_side(target)
    if source_side and target_side and source_side != target_side:
        raise MappingError(f"left/right bone swap rejected: {source} -> {target}")


def build_bone_map(
    source_names: Iterable[str],
    target_names: Iterable[str],
    explicit: Mapping[str, str] | None = None,
) -> dict[str, str]:
    source = list(source_names)
    target = list(target_names)
    source_set = set(source)
    target_set = set(target)
    result: dict[str, str] = {}

    for source_name, target_name in (explicit or {}).items():
        if source_name not in source_set:
            raise MappingError(f"explicit source bone is missing: {source_name}")
        if target_name not in target_set:
            raise MappingError(f"explicit target bone is missing: {target_name}")
        _validate_pair(source_name, target_name)
        result[source_name] = target_name

    by_canonical: dict[str, list[str]] = {}
    for target_name in target:
        by_canonical.setdefault(canonical_bone_name(target_name), []).append(target_name)
    for source_name in source:
        if source_name in result:
            continue
        matches = by_canonical.get(canonical_bone_name(source_name), [])
        if len(matches) > 1:
            raise MappingError(f"ambiguous target bones for {source_name}: {matches}")
        if len(matches) == 1:
            _validate_pair(source_name, matches[0])
            result[source_name] = matches[0]
    return result


def remap_data_path(data_path: str, bone_map: Mapping[str, str]) -> str | None:
    match = _BONE_PATH.search(data_path)
    if not match:
        return data_path
    source_name = match.group(2)
    target_name = bone_map.get(source_name)
    if target_name is None:
        return None
    start, end = match.span(2)
    return data_path[:start] + target_name + data_path[end:]


def remap_location_value(
    value: float,
    array_index: int,
    root_motion: str,
    scale_ratio: float,
) -> float:
    if root_motion not in {"keep", "in_place"}:
        raise MappingError(f"unknown root motion mode: {root_motion}")
    if root_motion == "in_place" and array_index in {0, 1}:
        return 0.0
    return float(value) * float(scale_ratio)


def axis_angle_degrees(first: Iterable[float], second: Iterable[float]) -> float:
    a = tuple(float(value) for value in first)
    b = tuple(float(value) for value in second)
    if len(a) != 3 or len(b) != 3:
        raise MappingError("bone axes must contain three values")
    length_a = math.sqrt(sum(value * value for value in a))
    length_b = math.sqrt(sum(value * value for value in b))
    if length_a == 0 or length_b == 0:
        raise MappingError("bone axis cannot be zero length")
    cosine = sum(left * right for left, right in zip(a, b)) / (length_a * length_b)
    return math.degrees(math.acos(max(-1.0, min(1.0, cosine))))
