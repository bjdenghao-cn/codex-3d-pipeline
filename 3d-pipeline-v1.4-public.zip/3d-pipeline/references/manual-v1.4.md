# 《3D流水线执行器 使用手册》

## 版本：V1.4

适用于 1–30 秒 UE 质感 3D 广告。V1.4 在 V1.3 的质量和审批规则上加入真实执行器：每一阶段有确定输入、命令、输出、报告、哈希和状态；失败不能越级。

## 1. 阶段顺序

1. `preflight`：确认 Blender、Godot、FFmpeg/FFprobe 的真实路径和版本。
2. `blender_mcp_gate`：必要时启动 Blender GUI，以协议握手和场景查询验证 MCP 实时可用。
3. `asset_gate`：验证生成资产的轮廓、材质、拓扑和可绑定性。
4. `mixamo_handoff`：把本地 Mixamo FBX 动作映射到已绑定角色并导出 Godot GLB。
5. `rig_gate`：验证骨架、权重、动作、手部与交互。
6. `export_gate`：重新导入 FBX/GLB 后复验。
7. `godot_gate`：验证引擎导入、实际骨骼变形、时间线和项目契约。
8. `representative_frame`：用正式资产和正式灯光渲染代表帧。
9. `final_render`：代表帧获用户明确接受后渲染完整时间线。

阶段命令返回非零、报告不是 `PASS`、输出缺失或审批缺失时，执行器立即停止。修复输入后重跑；输入哈希改变会让本阶段及后续缓存失效。

## 2. 初始化与运行

```powershell
$python = 'C:\path\to\python.exe'
$executor = Join-Path $env:USERPROFILE '.codex\skills\3d-pipeline\scripts\pipeline.py'

& $python $executor init `
  --workspace 'C:\path\to\project' `
  --name 'project-name' `
  --quality Q2 `
  --duration 15 `
  --fps 30 `
  --resolution 1080x1920
```

初始化后配置 `3d-pipeline.json` 中的各阶段，再分段执行：

```powershell
& $python $executor run --config 'C:\path\to\project\3d-pipeline.json' --through asset_gate
& $python $executor status --config 'C:\path\to\project\3d-pipeline.json'
```

新合同故意把生产阶段标记为 `configured: false`；必须绑定项目自己的正式输入、输出和门禁报告后才能运行。

## 3. 资产门禁

`blender_asset_gate.py` 支持 `.blend`、`.glb/.gltf` 和 `.fbx`。人物 Q2 合同至少提供左右手分析区域。脚本统一到目标身高坐标后检查：

- 顶点、三角面、材质、图片和非流形边数量；
- 手部选区内总连通壳和显著连通壳；
- Q2 是否同时配置左右手区域。

区域边界会切断穿越边界的网格，因此 `max_total_components` 是保守报警值；最终判断同时看显著壳数量和多视图。资产门禁通过仍不等于视觉接受。

若 AI 手部含大量断开或重叠壳、手指融合、背面猜错，优先重新生成完整 T/A-Pose 角色或采用具有连续变形拓扑的合规基础角色。不要直接进入自动权重。

## 4. 骨骼和握持门禁

`blender_rig_gate.py` 对 Blender 工程和导出文件使用同一套合同，检查：

- 正式网格可见，Armature Modifier 指向目标骨架；
- 必需骨骼、顶点组及最低权重点数量；
- 指定动作存在，并在 rest/pose 两帧之间真正改变可见网格；
- 手部边长拉伸不超过项目阈值；
- 每根手指到固定握把表面的距离；
- 拇指与其余四指的对向关系；
- 掌部侵入握把的最大深度；
- 手掌中心到固定握点的距离。

握把的中心、轴、半长和半径必须在摆手之前由真实武器确定。左右手坐标、骨轴、武器朝向和镜头可读性都是项目配置，不使用全局硬编码。

Q2 自动化的可靠停止规则：如果源手不是连续、能分出五指的变形表面，返回失败。Voxel Remesh 可用于身体求权重代理，但不能成为高精度手的成品拓扑。

## 5. 动作与 Mixamo

执行器不会代替用户登录网页或绕过第三方许可。Mixamo 没有已验证的自动接口时，把用户合法下载的 T-Pose/动作 FBX 作为哈希输入；Blender 完成骨架映射、重定向、Root Motion、Socket 和导出，随后运行 `rig_gate` 与 `export_gate`。

固定一个项目级骨架字典，明确 Blender 骨名、外部动作骨名和 Godot Skeleton3D 骨名。动作存在但网格不动、左右骨交换、骨轴翻转或单位变化都必须失败。

先准备 Mixamo 交接配置：

```json
{
  "base_character": "assets/character-with-mixamo-rig.fbx",
  "target_armature": "Armature",
  "required_bones": ["Hips", "LeftArm", "RightArm", "LeftHand", "RightHand"],
  "root_bone": "Hips",
  "max_rest_axis_angle_degrees": 15.0,
  "max_rest_basis_angle_degrees": 15.0,
  "bone_map": {
    "mixamorig:LeftForeArm": "forearm.L",
    "mixamorig:RightForeArm": "forearm.R"
  },
  "motions": [
    {"path": "motions/idle.fbx", "name": "Idle", "root_motion": "in_place"},
    {"path": "motions/walk.fbx", "name": "Walk", "root_motion": "keep"},
    {"path": "motions/shoot.fbx", "name": "Shoot", "root_motion": "in_place"}
  ],
  "output_blend": "build/character-actions.blend",
  "output_glb": "godot_project/assets/character-actions.glb",
  "output_report": "reports/mixamo-handoff.json"
}
```

再把它写入流水线并运行：

```powershell
& $python $executor configure-mixamo `
  --config 'C:\path\to\project\3d-pipeline.json' `
  --mixamo-config 'C:\path\to\project\mixamo-handoff.json'

& $python $executor run `
  --config 'C:\path\to\project\3d-pipeline.json' `
  --through mixamo_handoff
```

同名前缀差异会自动匹配；不同命名体系必须提供 `bone_map`。直接复制局部动作只允许在休止骨方向和完整旋转基底（含 bone roll）差异均不超过合同阈值时执行，超过阈值返回 `REST_AXIS_MISMATCH` 或 `REST_BASIS_MISMATCH`，不得带病导出。`in_place` 会清除根骨水平位移但保留竖直位移；每个动作还必须在目标骨架上产生真实姿态变化。

## 6. Godot 门禁

项目拥有自己的 GDScript 验证器。`godot_project_gate.py` 用 Godot CLI 运行它，同时要求：

- 进程退出码为 0；
- 标准输出含合同指定成功标记；
- 项目验证器检查实际 Skeleton3D 骨姿态或 skinned mesh 变形，而非只看播放器状态；
- 正式资产没有被隐藏并由可见代理替代；
- 相机、灯光、角色数量、事件点、时长和安全区符合项目合同。

Godot-MCP 不存在时继续使用 CLI/GDScript；必须记录实际通信方式。Blender-MCP 在 GUI 未连接或 `blender -b` 时不可用；默认 `blender_mcp_gate` 会启动 GUI 并等待端口，且每次运行都重新握手，不能复用旧缓存。

## 7. 审批

只有用户在当前任务明确同意后才能记录审批：

```powershell
& $python $executor approve `
  --config 'C:\path\to\project\3d-pipeline.json' `
  --gate representative_frame_accepted `
  --actor user `
  --note '用户确认版本 A'
```

审批只解锁合同中声明 `requires_approvals` 的阶段。修改合同会清除全部审批，防止旧许可用于新模型、数量、费用或画面。

## 8. 质量边界

- Q0：只能验证空间、相机、路径和时长；必须标注占位。
- Q1：正式游戏广告资产，完整 UV/PBR、轮廓和中景动作。
- Q2：脸、五指、握持、方向盘或机械近景；要求额外拓扑、权重和交互验证。

技术导入、骨骼数量、命令退出 0、视频可解码都不是视觉接受。报告始终区分资产技术状态、Blender 状态、导出状态、Godot 状态、独立视觉检查和用户最终接受。
