#!/usr/bin/env python3
"""Run a project-owned Godot validator and emit the V1.4 gate protocol."""

from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path
from typing import Any


def build_report(returncode: int, stdout: str, stderr: str, success_marker: str) -> dict[str, Any]:
    failures = []
    if returncode != 0:
        failures.append({"code": "GODOT_VALIDATOR_EXIT", "exit_code": returncode})
    if success_marker not in stdout:
        failures.append({"code": "GODOT_SUCCESS_MARKER_MISSING", "marker": success_marker})
    return {
        "status": "FAIL" if failures else "PASS",
        "gate": "godot_gate",
        "failure_codes": failures,
        "success_marker": success_marker,
        "stdout": stdout[-20000:],
        "stderr": stderr[-20000:],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--godot", required=True)
    parser.add_argument("--project", required=True)
    parser.add_argument("--validator", required=True, help="Godot res:// validator script")
    parser.add_argument("--success-marker", default="GODOT_GATE_OK")
    parser.add_argument("--timeout-seconds", type=int, default=300)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = Path(args.project).resolve()
    try:
        completed = subprocess.run(
            [args.godot, "--headless", "--path", str(project), "--script", args.validator],
            text=True,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            timeout=args.timeout_seconds,
            shell=False,
        )
        report = build_report(completed.returncode, completed.stdout, completed.stderr, args.success_marker)
    except subprocess.TimeoutExpired as exc:
        report = {
            "status": "FAIL",
            "gate": "godot_gate",
            "failure_codes": [{"code": "GODOT_VALIDATOR_TIMEOUT", "seconds": args.timeout_seconds}],
            "success_marker": args.success_marker,
            "stdout": exc.stdout if isinstance(exc.stdout, str) else "",
            "stderr": exc.stderr if isinstance(exc.stderr, str) else "",
        }
    report.update({"project": str(project), "validator": args.validator})
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
