import sys
import unittest
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from godot_project_gate import build_report


class GodotGateTests(unittest.TestCase):
    def test_zero_exit_without_runtime_marker_is_a_failure(self):
        report = build_report(0, "scene loaded", "", "GODOT_GATE_OK")

        self.assertEqual(report["status"], "FAIL")
        self.assertEqual(report["failure_codes"][0]["code"], "GODOT_SUCCESS_MARKER_MISSING")

    def test_nonzero_exit_with_marker_is_still_a_failure(self):
        report = build_report(7, "GODOT_GATE_OK", "crash", "GODOT_GATE_OK")

        self.assertEqual(report["status"], "FAIL")
        self.assertEqual(report["failure_codes"][0], {"code": "GODOT_VALIDATOR_EXIT", "exit_code": 7})

    def test_zero_exit_and_runtime_marker_pass(self):
        report = build_report(0, "GODOT_GATE_OK\n", "", "GODOT_GATE_OK")

        self.assertEqual(report["status"], "PASS")
        self.assertEqual(report["failure_codes"], [])


if __name__ == "__main__":
    unittest.main()
