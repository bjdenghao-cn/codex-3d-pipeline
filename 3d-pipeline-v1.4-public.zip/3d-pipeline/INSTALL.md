# 3D流水线 V1.4｜公开通用版安装说明

这不是一段提示词，而是包含执行器、门禁脚本、测试和说明文档的真实 Codex Skill。

## 安装

1. 解压压缩包，确认最外层文件夹名为 `3d-pipeline`。
2. 把整个文件夹复制到：

   ```text
   C:\Users\你的用户名\.codex\skills\3d-pipeline
   ```

3. 关闭并重新打开 Codex。
4. 新建任务，输入：

   ```text
   使用 $3d-pipeline，先检查我的电脑是否满足运行条件。
   暂时不要生成资产，也不要渲染完整视频。
   请告诉我当前停在哪个阶段、缺什么软件或插件，以及下一步需要我确认什么。
   ```

## 最小环境

- Python 3
- Blender
- Godot 4
- FFmpeg / FFprobe
- Codex

V1.4 新建项目默认启用 `blender_mcp_gate`，所以按默认九阶段执行时需要 Blender MCP 实时连接；仅仅显示“插件已安装”不算通过，必须完成协议握手并成功读取场景。熟悉流水线合同的用户可以把该阶段重新配置为自己的 Blender CLI/Python 健康检查路线。Godot 默认使用 CLI/GDScript，不要求安装 Godot MCP。Mixamo 是外部网页服务，不是插件，登录、上传和下载由用户自己完成。

## 第一次验证

在 PowerShell 中运行：

```powershell
$skill = Join-Path $env:USERPROFILE '.codex\skills\3d-pipeline'
python "$skill\scripts\pipeline.py" --help
python -m unittest discover -s "$skill\scripts\tests" -p 'test_*.py'
```

出现命令帮助，并且测试显示 `OK`，表示执行器本身可以运行。它不代表 Blender、Godot、MCP 或项目资产已经通过生产门禁。

## 创建一个 15 秒项目

```powershell
$skill = Join-Path $env:USERPROFILE '.codex\skills\3d-pipeline'
$project = 'D:\3d-ad-demo'

python "$skill\scripts\pipeline.py" init `
  --workspace $project `
  --name 'ue-style-15s-ad' `
  --quality Q1 `
  --duration 15 `
  --fps 30 `
  --resolution 1080x1920

python "$skill\scripts\pipeline.py" status `
  --config "$project\3d-pipeline.json"
```

初始化只创建真实项目合同和状态文件，不会擅自调用付费生成、安装插件或渲染完整视频。后续由 Codex 根据项目资产配置九个阶段。

## 九个阶段

```text
preflight
→ blender_mcp_gate
→ asset_gate
→ mixamo_handoff
→ rig_gate
→ export_gate
→ godot_gate
→ representative_frame
→ final_render
```

任何失败、缺文件、输入变化、缺少审批或代表帧未接受都会停止。只有用户明确确认代表帧后，才能运行完整渲染。
