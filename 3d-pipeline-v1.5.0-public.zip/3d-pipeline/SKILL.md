---
name: 3d-pipeline
description: Use when creating 1–30 second AI-assisted Blender-to-Godot 3D advertisements with UE-like visual quality, especially when generated assets need riggability, skeleton, skin-weight, hand-grip, export, representative-frame, scene-semantics, or resumable pipeline gates.
---

# 3D流水线 V1.5 执行器

把需求、正式资产、Blender 工程化、Godot 自动编排和最终视频组织成可断点、可审计、失败即停的流水线。Codex 驱动执行；不要把 Godot 动画、镜头、灯光或剪辑转交给用户。

基础生产规则见 [V1.4 使用手册](references/manual-v1.4.md)，V1.5 的项目语义、乘员/载具和特效门禁见 [视觉与动作合理性门禁](references/visual-action-gates-v1.5.md)。配置字段和命令见 [执行器协议](references/executor-v1.4.md)。

## 默认执行方式

1. 在目标项目运行 `scripts/pipeline.py init`，生成 `3d-pipeline.json` 和 `.3d-pipeline/run-state.json`。
2. 按项目实际资产填写门禁命令、输入、输出和 JSON 报告；不得把凭据写进合同或命令参数。
3. 依次执行 `preflight → blender_mcp_gate → asset_gate → mixamo_handoff → rig_gate → export_gate → godot_gate → representative_frame → final_render`。使用 `run --through <stage>` 做分阶段执行。
4. 读取状态和门禁报告。任何 `FAIL`、非零退出、缺文件、输入哈希变化、未配置阶段或缺审批都必须停止。
5. 只有用户在当前任务明确同意相应操作后，才能用 `approve` 记录付费生成、失败重试、许可/商用设置或代表帧接受。审批绑定当前合同；合同变化自动清除。

## 骨骼硬门禁

- `asset_gate` 必须早于任何自动绑骨。Q2 人物必须检查左右手区域、断开/重叠壳、五指可分性、非流形和材质；不适合绑定时返回 `SOURCE_NOT_RIGGABLE` 或具体失败码，不得用权重修补掩盖源网格失败。
- 身体/四肢可使用连续代理求权重；高精度手指不得依赖 Voxel Remesh、最近面贴图或程序化替代手冒充正式资产。
- `rig_gate` 必须检查正式可见网格被骨骼真实驱动、必需骨骼和权重存在、动作产生实际变形、表面不过度拉伸。
- 任何握持动作都先固定真实武器、左右握点、轴和半径，再检查五指接触、拇指对握、掌心穿透、腕部方向和左右手身份。禁止从已变形手的位置反推握点再验证。
- `export_gate` 对导出的 FBX/GLB 重新导入后再次运行骨骼门禁；Blender 内通过不代表引擎资产通过。
- `godot_gate` 必须由项目验证脚本检查 `Skeleton3D` 的实际非恒等变形，并输出约定成功标记；仅有动画名或 `AnimationPlayer.play()` 不算通过。

## 项目语义硬门禁

- 每个新剧情先从用户需求生成项目专属的角色、载具、交互、因果和 VFX 合同；不要把某个项目的坐标或“司机坐姿”等具体语义变成所有项目的固定规则。
- 正式主角资产必须记录来源和正式状态。生成模型、授权资产或摄影测量可作为正式源；程序化几何默认只是 Q0，占据近景前必须获得用户明确接受的回退审批。
- 角色与载具/道具的关系要用可测数据验证：座位/脚舱/握点接触、关节角度、父级与运动空间。复制 `Idle` 后只改动作名不算新动作。
- 载具必须验证模型前轴与运动方向点积、连续位移和相机相对方位；车头反向、倒着前进或镜头跨轴必须失败。
- 正式爆炸/烟雾不得使用不透明球体或圆柱堆叠。项目报告必须证明软透明、闪光/火焰/烟/尘/碎片分层、随时间上升扩散和消隐、风向响应、遮挡时长及高光不过曝。
- 在 `godot_project_gate.py` 中传入 `--scene-semantics`；缺少项目要求的语义证据或返回任何失败码时，不得进入代表帧。

## 质量和授权边界

- Q0 只能做占位；参考图默认至少 Q1；手、脸、武器交互近景使用 Q2。
- 正式可见人物、车辆、武器和核心场景不能由方块、圆柱或隐藏代理替代。
- Blender CLI 用于确定性构建和门禁；`blender_mcp_gate` 在需要时启动 GUI 进程并用协议握手和场景查询证明实时连接，不能用 `blender -b` 或“插件已安装”冒充 MCP 可用。Godot 无插件时使用 CLI 和项目 GDScript。
- Mixamo 登录、上传与下载仍由用户按许可完成；取得 rigged character FBX 和本地动作 FBX 后，使用 `configure-mixamo` 写入交接阶段，自动完成骨名映射、左右侧保护、骨轴门禁、Root Motion、动作写入和 Godot GLB 导出。
- 外部生成、额度消耗、授权许可、失败重试和最终创意接受仍由用户决定。执行器默认不包含付费提交命令。
- 代表帧必须来自正式 Godot 场景；用户明确接受后才允许完整渲染。技术通过、视觉检查和用户接受分别记录。

## 内置脚本

- `scripts/pipeline.py`：初始化、运行、断点恢复、审批和状态查询。
- `scripts/blender_mcp_gate.py`：实时协议/场景查询，并可在断线时启动 Blender GUI 后等待连接。
- `scripts/blender_asset_gate.py`：源资产及手部连通性门禁。
- `scripts/blender_mixamo_handoff.py`：把本地 Mixamo 动作 FBX 映射到角色骨架，保存 `.blend` 并导出 Godot GLB。
- `scripts/mixamo_mapping.py`：骨名标准化、左右侧保护、动作路径和 Root Motion 映射。
- `scripts/blender_rig_gate.py`：`.blend/.glb/.fbx` 骨骼、权重、变形和物理握持门禁。
- `scripts/godot_project_gate.py`：运行项目验证脚本，要求真实成功标记，并可验证项目语义、载具乘员和 VFX 报告。

先运行各脚本的 `--help`；门禁阈值属于项目合同，不要把某一个角色的坐标或误差当成全局常量。
