# 3D流水线 V1.5 安装说明

这是一个可直接安装到 Codex 的通用 Skill，用于自动执行 1–30 秒 AI 3D 广告的 Blender → Godot 流程，并以代表帧作为正式渲染前的用户确认点。

## 1. 准备环境

- Codex Desktop 或 Codex CLI
- Python 3.10 或更高版本
- Blender 4.x
- Godot 4.x
- FFmpeg 与 FFprobe
- 可选：Blender MCP，用于需要实时操作 Blender GUI 的项目
- 可选：Mixamo，用户自行合法下载 T-Pose 或动作 FBX；Skill 不代替登录或下载

UE 不是必装项。本 Skill 用 Blender 和 Godot 自动完成工程与渲染，并以灯光、材质、镜头和后期获得 UE 质感；如项目必须进入 Unreal Engine，可把 `export_gate` 的 GLB/FBX 作为交接资产。

## 2. 安装

解压后，确保最终目录是：

```text
%USERPROFILE%\.codex\skills\3d-pipeline\SKILL.md
```

PowerShell 示例：

```powershell
$target = Join-Path $env:USERPROFILE '.codex\skills\3d-pipeline'
New-Item -ItemType Directory -Force -Path $target | Out-Null
Copy-Item -Recurse -Force '.\3d-pipeline\*' $target
```

重启 Codex 后，在新任务中输入：

```text
使用 $3d-pipeline 制作一条 15 秒、9:16、明亮自然光、干净无杂色、克制纹理、原创角色的 UE 质感 3D 广告。
先生成项目合同和代表帧，通过我的确认后再渲染全片。
```

## 3. 小白只要确认四件事

1. 广告时长、比例、人物和剧情是否写对。
2. 使用哪些正式资产，来源和商用许可是否明确。
3. 代表帧中的角色、载具、光线、镜头和特效是否正确。
4. 是否同意正式渲染；付费生成、重试和发布仍需单独明确同意。

## 4. 自动执行顺序

```text
preflight
→ blender_mcp_gate
→ asset_gate
→ mixamo_handoff
→ rig_gate
→ export_gate
→ godot_gate
→ representative_frame
→ final_render
```

V1.5 新增 `scene-semantics` 硬门禁，会检查角色与载具/道具关系、载具前进方向、相机方位，以及爆炸、烟雾、尘土等 VFX 的层次和运动合理性。任何关键证据缺失都会停止，不会直接进入最终渲染。

## 5. 验证安装

```powershell
$skill = Join-Path $env:USERPROFILE '.codex\skills\3d-pipeline'
python -m unittest discover -s "$skill\scripts\tests" -p 'test_*.py'
python "$skill\scripts\pipeline.py" --help
```

看到测试通过并显示命令帮助，即表示执行器可以运行。项目仍需按 `references/manual-v1.4.md` 建立合同，并按 `references/visual-action-gates-v1.5.md` 提供 V1.5 语义报告。
