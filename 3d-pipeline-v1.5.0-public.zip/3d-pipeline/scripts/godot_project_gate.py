#!/usr/bin/env python3
"""Run a project-owned Godot validator and emit the V1.5 gate protocol."""

from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path
from typing import Any


def validate_scene_semantics(scene: dict[str, Any], contract: dict[str, Any]) -> list[dict[str, Any]]:
    """Validate project-reported spatial, action, asset-source, and VFX semantics."""
    failures: list[dict[str, Any]] = []
    allowed_sources = set(contract.get("allowed_hero_asset_sources", ["hunyuan3d", "licensed_asset", "photogrammetry"]))
    maximum_contact = float(contract.get("maximum_contact_error_m", 0.10))
    maximum_foot = float(contract.get("maximum_footwell_error_m", 0.18))
    minimum_forward_dot = float(contract.get("minimum_forward_dot", 0.98))
    maximum_occlusion = int(contract.get("maximum_strong_occlusion_frames", 7))
    maximum_white_clip = float(contract.get("maximum_white_clip_ratio", 0.08))
    minimum_depth_layers = int(contract.get("minimum_environment_depth_layers", 3))
    minimum_setpieces = int(contract.get("minimum_unique_setpieces", 2))
    maximum_repetition = float(contract.get("maximum_repetition_score", 0.35))
    maximum_empty_screen = float(contract.get("maximum_empty_screen_ratio", 0.45))
    minimum_camera_coverage = float(contract.get("minimum_camera_path_coverage", 0.90))

    hero_vehicle = scene.get("hero_assets", {}).get("vehicle")
    if not isinstance(hero_vehicle, dict) or not hero_vehicle.get("formal", False):
        failures.append({"code": "HERO_VEHICLE_NOT_FORMAL"})
    elif hero_vehicle.get("source") not in allowed_sources and not hero_vehicle.get("fallback_approved", False):
        failures.append({"code": "HERO_ASSET_SOURCE_UNAPPROVED", "source": hero_vehicle.get("source")})

    environment = scene.get("environment")
    if not isinstance(environment, dict) or not environment.get("formal", False):
        failures.append({"code": "ENVIRONMENT_NOT_FORMAL"})
    if isinstance(environment, dict):
        if environment.get("q0_visible", True):
            failures.append({"code": "Q0_VISIBLE_IN_FORMAL_SCENE"})
        if environment.get("ground_material") != "pbr":
            failures.append({"code": "GROUND_MATERIAL_NOT_PBR"})
        if int(environment.get("depth_layers", 0)) < minimum_depth_layers:
            failures.append({"code": "ENVIRONMENT_DEPTH_INSUFFICIENT"})
        if int(environment.get("unique_setpieces", 0)) < minimum_setpieces:
            failures.append({"code": "ENVIRONMENT_SETPIECES_INSUFFICIENT"})
        if float(environment.get("repetition_score", 1.0)) > maximum_repetition:
            failures.append({"code": "ENVIRONMENT_REPETITION_EXCESSIVE"})
        if float(environment.get("empty_screen_ratio", 1.0)) > maximum_empty_screen:
            failures.append({"code": "ENVIRONMENT_TOO_EMPTY"})
        if float(environment.get("camera_path_coverage", 0.0)) < minimum_camera_coverage:
            failures.append({"code": "ENVIRONMENT_CAMERA_PATH_UNCOVERED"})

    hero_vehicles = [item for item in scene.get("vehicles", []) if item.get("role") == "hero"]
    if not hero_vehicles:
        failures.append({"code": "HERO_VEHICLE_REPORT_MISSING"})
    for vehicle in hero_vehicles:
        if not vehicle.get("continuous_forward", False):
            failures.append({"code": "VEHICLE_FORWARD_MOTION_MISSING", "id": vehicle.get("id")})
        if float(vehicle.get("forward_dot", -1.0)) < minimum_forward_dot:
            failures.append({"code": "VEHICLE_FORWARD_AXIS_MISMATCH", "id": vehicle.get("id")})

    drivers = [item for item in scene.get("riders", []) if item.get("role") == "driver"]
    if not drivers:
        failures.append({"code": "DRIVER_REPORT_MISSING"})
    for driver in drivers:
        if driver.get("posture") != "seated":
            failures.append({"code": "DRIVER_NOT_SEATED", "id": driver.get("id")})
            continue
        for field, low, high, code in (
            ("hip_flexion_deg", 55.0, 125.0, "DRIVER_HIP_ANGLE_INVALID"),
            ("knee_flexion_deg", 55.0, 145.0, "DRIVER_KNEE_ANGLE_INVALID"),
        ):
            value = float(driver.get(field, -1.0))
            if not low <= value <= high:
                failures.append({"code": code, "id": driver.get("id"), "actual": value})
        for field in ("seat_contact_m", "left_hand_target_m", "right_hand_target_m"):
            value = float(driver.get(field, 1e9))
            if value > maximum_contact:
                failures.append({"code": "DRIVER_CONTACT_MISSED", "id": driver.get("id"), "field": field, "actual": value})
        for field in ("left_foot_target_m", "right_foot_target_m"):
            value = float(driver.get(field, 1e9))
            if value > maximum_foot:
                failures.append({"code": "DRIVER_FOOTWELL_MISSED", "id": driver.get("id"), "field": field, "actual": value})

    required_layers = {"flash", "fire", "smoke", "dust", "debris"}
    for effect in [item for item in scene.get("vfx", []) if item.get("kind") == "explosion"]:
        if effect.get("representation") in {"opaque_primitive_stack", "solid_spheres"} or not effect.get("soft_alpha", False):
            failures.append({"code": "VFX_OPAQUE_PRIMITIVE_SMOKE", "id": effect.get("id")})
        missing = sorted(required_layers - set(effect.get("layers", [])))
        if missing:
            failures.append({"code": "VFX_LAYERS_MISSING", "id": effect.get("id"), "layers": missing})
        if float(effect.get("smoke_rise_mps", 0.0)) <= 0.0 or not effect.get("opacity_decay", False) or not effect.get("wind_response", False):
            failures.append({"code": "VFX_SMOKE_EVOLUTION_MISSING", "id": effect.get("id")})
        if int(effect.get("max_strong_occlusion_frames", 10**9)) > maximum_occlusion:
            failures.append({"code": "VFX_OCCLUSION_TOO_LONG", "id": effect.get("id")})
        if float(effect.get("white_clip_ratio", 1.0)) > maximum_white_clip:
            failures.append({"code": "VFX_HIGHLIGHT_CLIPPING", "id": effect.get("id")})
    return failures


def build_report(returncode: int, stdout: str, stderr: str, success_marker: str) -> dict[str, Any]:
    failures = []
    if returncode != 0:
        failures.append({"code": "GODOT_VALIDATOR_EXIT", "exit_code": returncode})
    if success_marker not in stdout:
        failures.append({"code": "GODOT_SUCCESS_MARKER_MISSING", "marker": success_marker})
    return {
        "status": "FAIL" if failures else "PASS",
        "gate": "godot_gate",
        "failure_codes": failures,
        "success_marker": success_marker,
        "stdout": stdout[-20000:],
        "stderr": stderr[-20000:],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--godot", required=True)
    parser.add_argument("--project", required=True)
    parser.add_argument("--validator", required=True, help="Godot res:// validator script")
    parser.add_argument("--success-marker", default="GODOT_GATE_OK")
    parser.add_argument("--timeout-seconds", type=int, default=300)
    parser.add_argument("--scene-semantics", help="Project JSON report for spatial/action/VFX semantics")
    parser.add_argument("--semantics-contract", help="Optional JSON thresholds for semantic validation")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = Path(args.project).resolve()
    try:
        completed = subprocess.run(
            [args.godot, "--headless", "--path", str(project), "--script", args.validator],
            text=True,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            timeout=args.timeout_seconds,
            shell=False,
        )
        report = build_report(completed.returncode, completed.stdout, completed.stderr, args.success_marker)
        if args.scene_semantics:
            scene_path = Path(args.scene_semantics).resolve()
            contract = json.loads(Path(args.semantics_contract).read_text(encoding="utf-8")) if args.semantics_contract else {}
            semantic_failures = validate_scene_semantics(json.loads(scene_path.read_text(encoding="utf-8")), contract)
            report["scene_semantics"] = str(scene_path)
            report["failure_codes"].extend(semantic_failures)
            report["status"] = "FAIL" if report["failure_codes"] else "PASS"
    except subprocess.TimeoutExpired as exc:
        report = {
            "status": "FAIL",
            "gate": "godot_gate",
            "failure_codes": [{"code": "GODOT_VALIDATOR_TIMEOUT", "seconds": args.timeout_seconds}],
            "success_marker": args.success_marker,
            "stdout": exc.stdout if isinstance(exc.stdout, str) else "",
            "stderr": exc.stderr if isinstance(exc.stderr, str) else "",
        }
    report.update({"project": str(project), "validator": args.validator})
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
